<template lang="html">
    <div>
        <div class="container-fluid about-banner">
            <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8 text-light">
                        <h2><b>About Us</b></h2>
                        <p>Partner with a well-rounded team of Specialists with deep experience in Finance Function,
                            Technology and Industry to meet your Business Goals</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container  py-5">
            <div class="row g-0 justify-center align-items-center">
                <div class="col-md-8 col-lg-5 col-sm-12 col-12">
                    <div class="card-img" style="max-width: 440px;">
                        <img src="img/why-us-hero.png" class="img-fluid rounded-start" alt="...">
                    </div>
                </div>
                <div class="col-md-8 col-sm-12 col-12 col-lg-6">
                    <div class="about-text">
                        <div class="why-us">
                            <div class="card-body">
                                <h3 class="card-title text-end" style="float:left"><b>Who we are</b></h3><br><br>

                                <p class="card-text p-2">ValueXPA is a Global technology-enabled Finance-as-a-Service
                                    Partner for Small and Mid-sized Businesses and Institutions. We help organizations
                                    with
                                    critical Management Decisions, Financial/operational reporting and insights through
                                    our unique blend
                                    of Extended Planning & Analysis (XP&A), Analytical Process Automation & Data
                                    Analytics,
                                    Management consulting and Finance Process Managed Services. The Firm’s Global
                                    footprint includes
                                    Clients across US, Australia and India and we have served over 50 clients Globally
                                    so far.<br>

                                    <br>We help SMBs and startups by providing them with expertise in SaaS,
                                    technology-enabled companies,
                                    and more. We have deep experience working with Fortune 500s, small businesses,
                                    mid-sized businesses,
                                    as well as startups. We believe in creating an environment of sustainable growth for
                                    their company's
                                    future success. We believe in combining Business and Financial Management Acumen,
                                    Structured Frameworks,
                                    Domain Expertise, Technology Solutions to solve business problems. In short, we help
                                    you as trusted
                                    Finance Business Partners and help you in:<br>
                                </p>

                                <ul>
                                    <li>Achieving greater financial visibility</li>
                                    <li>Effectively Raising, Planning and Managing your Finances</li>
                                    <li>Shaping up your business’ direction</li>
                                </ul>
                                <p>
                                    Our team offers the right balance of Management consultants, Financial planners,
                                    Data
                                    Scientists, Process Specialists and Data Storytellers.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container pt-5">
            <div class="row  justify-content-center">
                <h2 class="text-center fw-bold">Our Advisors</h2>

                <div class="col-lg-4">
                    <div class="team-container p-2 text-center my-1">
                        <img src="img/image.png" alt="" width="150" class="rounded-circle">
                        <div class="name-wrapper d-flex justify-content-between align-items-center text-light pt-3">
                            <div class="name text-start">
                                <h5>Ramesh Subramanian</h5>
                            </div>
                            <div class="">
                                <h2><a href="/profile3" class="text-light">+</a></h2>
                            </div>
                        </div>
                        <div class=" text-center">
                            <!-- <a href="www.linkedin.com/in/ramesh0508" target="_blank" class="mx-3 text-light">
                                <h3><i class="bi bi-linkedin"></i></h3></a> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="team-container p-2 text-center my-1">
                        <img src="img/image4.jpg" alt="" width="150" class="rounded-circle">
                        <div class="name-wrapper d-flex justify-content-between align-items-center text-light pt-3">
                            <div class="name text-start">
                                <h5>Sharat Satyanarayana</h5>
                            </div>
                            <div class="">
                                <h2><a href="/profile4" class="text-light">+</a></h2>
                            </div>
                        </div>
                        <div class=" text-center">
                            <!-- <a href="#" target="_blank" class="mx-3 text-light">
                                <h3><i class="bi bi-linkedin"></i></h3></a> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container pt-5">
            <div class="row  justify-content-center">
                <h2 class="text-center"><b>Our Team</b></h2>
                <div class="col-lg-4">
                    <div class="team-container p-2 text-center my-1">
                        <img src="img/boi-1.png" alt="" width="150" class="rounded-circle">
                        <div class="name-wrapper d-flex justify-content-between align-items-center text-light pt-3">
                            <div class="name text-start">
                                <h5>Karthikeyan V Raaj</h5>
                                <small><i></i></small>
                            </div>
                            <div class="text-light d-flex justify-content-between align-items-center">
                                <a href="https://www.linkedin.com/in/karthikeyanv/" target="_blank" class="text-light mx-3">
                                    <h3 class="mb-0"><i class="bi bi-linkedin"></i></h3>
                                </a>
                                <h2 class="mb-0">
                                    <a href="/profile1" class="text-light">+</a>
                                </h2>
                            </div>

                        </div>
                        <div class=" text-center">

                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="team-container p-2 text-center my-1">
                        <img src="img/bio-2.jfif" alt="" width="150" class="rounded-circle">
                        <div class="name-wrapper d-flex justify-content-between align-items-center text-light pt-3">
                            <div class="name text-start">
                                <h5>Srivathsan Sridharan</h5>
                            </div>
                            <div class="text-light d-flex">
                                <!-- <a href="https://www.linkedin.com/in/srivathsan296/" target="_blank"
                               class="mx-3 text-light"><h3><i class="bi bi-linkedin"></i></h3></a> -->
                                <h2><a href="/profile2" class="text-light">+</a></h2>
                            </div>
                        </div>
                        <div class=" text-center">
                            <!-- <a href="https://www.linkedin.com/in/jayanthrao/" target="_blank" class="mx-3 text-light">
                                <h3><i class="bi bi-linkedin"></i></h3></a> -->
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <Footer />
    </div>
</template>
<script>


import Footer from "../components/Footer.vue"

export default {

    components: {
        Footer,
    }
}
</script>
<style lang="">

</style>
