<template lang="html">
    <div class="hero-img">
        <div class="container mb-3">
            <div class="row justify-left align-left text-left content">
                <div class="col-lg-6 col-md-8">
                    <h1>Helping CFOs identify, protect, and unlock business values</h1>
                    <p>ValueXPA partners with CFOs to uncover hidden value leaks, strengthen financial control, and
                        enable confident, data-driven decisions.</p>

                    <div class="row mt-12 g-3">
                        <div class="col-md-6">
                            <a href="/Supply-Chain-Value-Leakage-Diagnostic" class="btn btn-primary w-100"> View
                                Flagship Offers</a>
                        </div>
                        <div class="col-md-6">
                            <a href="/contact-us" class="btn btn-primary w-100">Talk to an Advisor</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<div class="container mt-5 mb-3">
        <h4 class="siteblue text-center"><b>Our Testimonials</b></h4>

        <div id="testimonialCarousel" class="carousel slide testimonial-slider" data-bs-ride="carousel" data-bs-interval="5000">
            <div class="carousel-inner">
                <!-- Testimonial 1 -->
                <div class="carousel-item active testimonial-item">
                    <img src="img/testimonial/1.png" alt="Ramesh Subramanian" class="testimonial-img">
                    <p class="testimonial-text">
                        <i>"ValueXPA enhances Enterprise decision insights through technology and automation, delivering powerful analytics for The Board and CEOs' decision-making"</i>
                    </p>
                    <h5><strong>Mr. Ramesh Subramanian</strong></h5>
                    <p><em>Transformational Strategic CFO & Board Member, Global Conglomerates</em></p>
                </div>

                <!-- Testimonial 2 -->
                <div class="carousel-item testimonial-item">
                    <img src="img/testimonial/2.png" alt="Ramesh Subramanian" class="testimonial-img">
                    <p class="testimonial-text">
                        <i>"ValueXPA has been a fantastic partner in supporting our daily Finance Operations, Business transaction projects and ad hoc financial analysis."</i>
                    </p>
                    <h5><strong>Lane Elmer</strong></h5>
                    <p><em>CFO at Pioneer Management Consulting</em></p>
                </div>

                <!-- Testimonial 3 -->
                <div class="carousel-item testimonial-item">
                    <img src="img/testimonial/3.png" alt="Ramesh Subramanian" class="testimonial-img">
                    <p class="testimonial-text">
                        <i>"ValueXPA have been fantastic partners to us. Incredibly reliable and responsive, they needs."</i>
                    </p>
                    <h5><strong>Pete Enestrom</strong></h5>
                    <p><em>Founder & CEO at Learnexus</em></p>
                </div>

                <!-- Testimonial 4 -->
                <div class="carousel-item testimonial-item">
                    <img src="img/testimonial/5.jpeg" alt="Ramesh Subramanian" class="testimonial-img">
                    <p class="testimonial-text">
                        <i>"ValueXPA team has been helping Brite Dental Partners in streamlining our Finance, Accounting oversight and Controller functions and proven to be dependable and trustworthy partners."</i>
                    </p>
                    <h5><strong>Dr. Satish Pai</strong></h5>
                    <p><em>Founder & CEO at Brite Dental Partners, US</em></p>
                </div>

                <!-- Testimonial 5 -->
                <div class="carousel-item testimonial-item">
                    <img src="img/testimonial/5s.png" alt="Ramesh Subramanian" class="testimonial-img">
                    <p class="testimonial-text">
                        <i>"ValueXPA team was instrumental in automating our Financial Planning & Analysis (FP&A) reports. Their expertise in financial modeling, reporting automation, and project feasibility analysis not only reduced reporting time but also enhanced our analytical capabilities, leading to more insightful and efficient reporting."</i>
                    </p>
                    <h5><strong>Mohammed Afzal Volli</strong></h5>
                    <p><em>Director of Finance, RAKEZ, UAE</em></p>
                </div>
            </div>

            <!-- Carousel controls -->
            <button class="carousel-control-prev slider-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon bg-secondary rounded" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next slider-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon bg-secondary rounded" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
        <!-- New Section: What Holds CFOs Back -->
        <div class="container mb-5 py-5">
            <div class="row align-items-center">
                <h3 class="siteblue text-center mb-2"><b>What Holds CFOs Back</b></h3>

                <!-- Left Column: Image -->
                <div class="col-lg-10 col-md-10 mb-4 mb-md-0 mx-auto">
                    <div class="text-center">
                        <!-- Replace this with your actual image -->
                        <img src="img/tmp_7fbaf76a-ad74-4c92-8cf1-299eb16a5b98sheik.png"
                            alt="CFO Dashboard View - Visualizing financial challenges" class="img-fluid rounded"
                            style="max-height: 400px; object-fit: cover;">

                        <!-- <p class="mt-3 text-muted fst-italic">What CFOs deal with every day</p> -->
                    </div>
                </div>
            </div>
        </div>



        <div class="container mt-5 secont-container mb-5">
            <div class="card mb-3 position-relative">
                <div class="row g-0 justify-content-center align-items-center">
                    <!-- Image Section with Overlay Text -->
                    <div class="col-12 img-container">
                        <img src="img/why-us-hero1.png" class="img-fluid w-100 rounded" alt="valuexpa">
                    </div>
                    <div class="col-9" style="margin-top:-20%">
                        <div class="overlay-text p-4">
                            <h4 class="siteblue mb-4"><b>How CFOs Work With ValueXPA</b></h4>
                            <p class="siteblue mb-4"><strong>Our Flagship Offers</strong></p>

                            <!-- First Offer -->
                            <div class="offer-item mb-4">
                                <p class="siteblue mb-2"><strong>Supply Chain Value Leakage Diagnostic
                                        (Flagship)</strong></p>
                                <p class="mb-2">Identify hidden margin leakage across procurement, contracts, and
                                    accounts payable — in 30 days. Delivered by ValueXPA. Powered by Fynflo.</p>
                                <a href="/Supply-Chain-Value-Leakage-Diagnostic" class="text-decoration-none">Learn more
                                    →</a>
                            </div>

                            <!-- Second Offer -->
                            <div class="offer-item mb-4">
                                <p class="siteblue mb-2"><strong>Strategic Finance & Analytics Enablement</strong></p>
                                <p class="mb-2">Build strong FP&A, analytics, and decision support for the CFO and CEO
                                    office.</p>
                                <a href="/Supply-Chain-Value-Leakage-Diagnostic" class="text-decoration-none">Learn more →</a>
                            </div>

                            <!-- Third Offer -->
                            <div class="offer-item mb-4">
                                <p class="siteblue mb-2"><strong>Finance Process Managed Services</strong></p>
                                <p class="mb-2">Reliable, automated finance operations that free leadership time and
                                    reduce risk.</p>
                                <a href="/Finance-Processes-Managed-Services" class="text-decoration-none">Learn more →</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- This section was commented out but had structure issues -->
        <!-- Removed problematic commented section -->





        <!-- Whom we serve -->
        <div class="container-fluid main-serve mt-4 py-3">
            <div class="container py-5 my-5">
                <div class="row">
                    <div class="col-lg-3 align-self-center">
                        <div class="">
                            <h4 class="text-light"><b>Whom We Serve</b></h4><br>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="row">
                            <div class="col-lg-5 col-md-6 col-sm-6 d-flex align-items-stretch">
                                <div class="my-2 card-serve p-5">
                                    <div class="col-lg-4 mx-auto icon-card align-items-center text-center">
                                        <img src="/img/icon-problem.png" alt="" class="py-2" style="max-width: 40px;">
                                    </div>
                                    <p class="my-4 siteblue text-center"><strong>CFO Office</strong></p>
                                    <p class="text-black">We act as an extended finance team, helping CFOs balance
                                        control, insight, and strategic impact.</p>
                                </div>
                            </div>

                            <div class="col-lg-5 col-md-6 col-sm-6 d-flex align-items-stretch">
                                <div class="my-2 card-serve p-5">
                                    <div class="col-lg-4 mx-auto icon-card align-items-center text-center">
                                        <img src="/img/icon-problem.png" alt="" class="py-2" style="max-width: 40px;">
                                    </div>
                                    <p class="my-4 siteblue text-center"><strong>CEO Office</strong></p>
                                    <p class="text-black">We support CEOs with reliable financial data and clear
                                        insights to guide growth and risk decisions.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Whom we serve -->

        <!-- Whom we serve -->
        <div class="container-fluid services py-3">
            <div class="container py-4">
                <div class="row serve-2">
                    <div class="col-lg-12">
                        <div class="row d-flex justify-content-between">
                            <div class="px-2">
                                <h4 class="siteblue"><b>Industries We Work With</b></h4>
                            </div>

                            <!-- First Row: Two Columns -->
                            <div class="col-lg-6 col-md-6 col-sm-6 d-flex align-items-stretch">
                                <div class="my-2 card-serve p-3 mx-2 my-3">
                                    <div class="col-lg-12 py-3 icon-card-2 align-items-center text-center d-flex">
                                        <img src="/img/icon-problem.png" alt="" class="py-2" style="max-width: 40px;">
                                        <h4 class="my-4 siteblue"><strong>Technology:</strong></h4>
                                    </div>
                                    <p class="text-black">Helping high-growth tech businesses manage complexity, unit
                                        economics, and decision clarity.</p>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-6 d-flex align-items-stretch">
                                <div class="my-2 card-serve p-3 mx-2 my-3">
                                    <div class="col-lg-12 py-3 icon-card-2 align-items-center text-center d-flex">
                                        <img src="/img/icon-problem.png" alt="" class="py-2" style="max-width: 40px;">
                                        <h4 class="my-4 siteblue"><strong>Energy & Renewables</strong></h4>
                                    </div>
                                    <p class="text-black">Supporting finance discipline, compliance, and analytics in a
                                        rapidly evolving sector.</p>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-6 mx-auto d-flex align-items-stretch">
                                <div class="my-2 card-serve p-3 mx-2 my-3">
                                    <div class="col-lg-12 py-3 icon-card-2 align-items-center text-center d-flex">
                                        <img src="/img/icon-problem.png" alt="" class="py-2" style="max-width: 40px;">
                                        <h4 class="my-4 siteblue"><strong>Manufacturing & Industrials</strong></h4>
                                    </div>
                                    <p class="text-black">Strengthening financial control, uncovering cost and margin
                                        leakage, and improving operational decisions.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Whom we serve -->
        <!-- With Background -->
        <div class="container-fluid py-5 my-5" style="background-color: #f8f9fa;">
            <div class="container">
                <div class="row justify-content-center align-items-center" style="min-height: 150px;">
                    <div class="col-12 text-center">
                        <a href="/Supply-Chain-Value-Leakage-Diagnostic" class="btn btn-primary btn-lg px-5 py-3">
                            <strong>View Flagship Offers</strong>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <cookie-consent />
        <Footer />
    </div>
</template>

<!-- Optional: Add some custom CSS for better visual appearance -->
<style>
.comparative-table {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.table-row {
    transition: all 0.2s ease;
}

.table-row:hover {
    background-color: rgba(13, 110, 253, 0.05);
    transform: translateX(4px);
}

.bi-bar-chart-fill {
    opacity: 0.8;
}

@media (max-width: 768px) {
    .table-row .col-6 {
        padding-bottom: 12px;
    }

    .table-row .col-6:first-child {
        border-bottom: 1px dashed #dee2e6;
        padding-bottom: 12px;
        margin-bottom: 8px;
    }
}

.offer-item {
    border-left: 3px solid #0d6efd;
    padding-left: 15px;
    transition: all 0.3s ease;
}

.offer-item:hover {
    background-color: rgba(13, 110, 253, 0.05);
    padding-left: 20px;
}

.offer-item a {
    color: #0d6efd;
    font-weight: 500;
}

.offer-item a:hover {
    color: #0a58ca;
    text-decoration: underline;
}
</style>

<script>
import VueTidio from 'vue-tidio';
import Footer from "../components/Footer.vue"
import Testimonials from "../components/Testimonials.vue"
import CookieConsent from 'vue-cookieconsent-component'

export default {
    components: {
        Footer,
        Testimonials,
        CookieConsent
    },
}
</script>

<style lang="scss">
@import "./node_modules/vue-cookieconsent-component/src/scss/cookie-consent";
@import "./node_modules/vue-cookieconsent-component/src/scss/cookie-consent-bottom";
@import "./node_modules/vue-cookieconsent-component/src/scss/cookie-consent-transition";
</style>
