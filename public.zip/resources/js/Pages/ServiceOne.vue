<template lang="">
    <div>
        <div class="hero-img-2">
           <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8">
                        <h2><b>Extended Planning and Analysis</b></h2>
                        <p><b>Take your Financial Planning & Analysis to the next level by adopting the principles of Extended Planning & Analysis and a holistic thinking mindset in your Organization</b></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="service-wrapper-2">
            <h3 class="pt-4 siteblue mb-2"><b>Extended Planning & Analysis </b></h3>
        </div>
        <div class="container-fluid services-details">
            <div class="">

                <div class="row justify-content-center align-items-stretch">
    <div class="col-lg-6 bg-light left-service py-5">
        <div class="service-wrapper-2">
            <h4 class="siteblue"><strong>Elevate Your Financial Planning & Analysis with a Holistic Approach</strong></h4>
            <p>
                For CFOs to contribute strategically and offer a value-driven business partnership to CEOs and the Board,
                it is not enough to just focus on finance. Instead, CFOs must broaden their vision to cover all crucial business
                functions. Extended Planning & Analysis (XP&A) takes financial planning to the next level by integrating insights
                from across the entire organization—from Operations and Sales to Marketing and HR. It’s all about breaking down silos
                and ensuring that every decision is driven by up-to-date, accurate data.
            </p>
        </div>
    </div>

    <div class="col-lg-6 right-service text-light">
        <div class="py-5 service-wrapper-2">
            <div class="col-lg-10">
                <h4><strong>Start by Solving for Data, Analytics, and Leap into Business Performance Management</strong></h4>
                <p>
                    It’s a familiar struggle—data scattered across different systems, outdated processes slowing everything down,
                    and reports that never seem to arrive on time. Many finance teams spend hours consolidating data, only to realize
                    they’re working with outdated or incomplete information. This not only blocks deeper financial insights but also
                    limits the business’s ability to perform at its best. Without real-time data, critical decisions are made on guesswork,
                    and opportunities slip through the cracks.
                </p>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center align-items-stretch">
    <div class="col-lg-6 left-service py-5 text-light">
        <div class="service-wrapper-2">
            <h4 ><strong>Sound Familiar? You're Not Alone.</strong></h4>
            <p>
                Lack of standardized information across departments, delays in accessing real-time data, and unreliable insights hinder
                timely decision-making and strategic guidance for CFOs. CFOs everywhere face these common challenges:
            </p>
            <ul>
                <li>Data locked in silos</li>
                <li>Tedious data consolidation that eats up time</li>
                <li>Reporting delays that leave you one step behind</li>
                <li>Limited insights into overall business performance</li>
            </ul>
        </div>
    </div>

    <div class="col-lg-6 bg-light  right-service ">
        <div class="py-5 service-wrapper-2">
            <div class="col-lg-10">
                <h4 class="siteblue"><strong>How You Can Benefit</strong></h4>
                <p>
                    With our XP&A solutions, we help CFOs break down these barriers. By integrating Performance Management and
                    Analytical Automation, we create a single source of truth, giving you real-time insights whenever you need them.
                    Imagine rolling forecasts that update automatically, agile planning that adapts to change, and a finance team that
                    can finally focus on driving growth instead of being bogged down by the details.
                </p>
                <p>
                    With our help, you can stop reacting and start steering your business with confidence.
                </p>
            </div>
        </div>
    </div>
</div>
</div>
        </div>
        <div class="container">
            <h4 class="text-center py-5 siteblue"><b>Advantages XP&amp;A</b></h4>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="true" aria-controls="collapseExample">
                        <span>Agile Planning and Forecasting</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse show" id="collapseExample">
                    <div class="card card-body  advantage-content">
                    <p>  Integrated financial and operational planning helps drive a holistic approach to decision making, positively impacting ROI and bottom-line.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 ">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample1" aria-expanded="true" aria-controls="#multiCollapseExample1">
                        <span>Real-time Analytics & Insights</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample1">
                    <div class="card card-body advantage-content">
                    <p> Quicker identification of Performance Management opportunities and risk areas resulting in greater collaboration, coordinated response and Better alignment of Goals across teams and functions.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample3" aria-expanded="true" aria-controls="#multiCollapseExample3">
                        <span>Single Source of Truth and Unified Database of  Siloed Data</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample3">
                    <div class="card card-body  advantage-content">
                    <p>  Reducing or eliminating the need for manual data collection and deploying automated solutions for data blending, transformation, analysis and reporting. Increasing the Reliability, transparency, and Integrity of financial and operational data. </p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12  col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample4" aria-expanded="true" aria-controls="#multiCollapseExample4">
                        <span>Analytical and Process Workflow Automation</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample4">
                    <div class="card card-body  advantage-content">
                    <p>  Deploy robust and automated driver-based financial models and process workflows resulting in real-time insights.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample5" aria-expanded="true" aria-controls="#multiCollapseExample5">
                        <span>Business Partnering</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample5">
                    <div class="card card-body  advantage-content">
                    <p>  Finance function increasingly plays a business partnering role shaping the outcome of prudent and data-driven decision-making. </p>
                    </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="container-fluid section-1 py-5">
            <div class="container">
                <div class="row justify-content-center align-items-center service-wrapper">
                    <div class="col-lg-4 col-md-12 col-sm-12 col-12 card-row my-2   flex-column d-flex align-items-stretch" v-for="(card,index) in cardTitle" :key="card">
                       <div :class="index % 2 === 0 ? 'bg-light text-center py-3' : 'main-card text-center py-3'" id="navbar-example2" >
                            <img src="/img/icon-problem.png" alt="" width="40">
                            <p>{{card.title}}</p>
                            <ul class="nav nav-pills">
                                <li class="nav-item mx-auto btn btn-secondary ">
                                <a class="nav-link text-light" href="#scrollspyHeading1" @click="display(card)">View Details</a>
                                </li>
                            </ul>
                       </div>
                    </div>
                </div>
            </div>
        </div>
        <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-offset="0" class="scrollspy-example" tabindex="0" v-show="isHidden" >
            <h4 id="scrollspyHeading1"></h4>
            <div class="card mb-3 py-3">
                <div class="row g-0 justify-content-center align-items-center">
                    <div class="d-flex justify-content-center" style="max-width: 440px;" >
                        <div class="card-img">
                                <img src="img/why-us-hero.png" class="img-fluid rounded-start" alt="...">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-12 col-lg-4 ">
                        <div class="about-text">
                               <div class="why-us">
                                    <div class="card-body">
                                    <h5 class="card-title text-end py-3"><b>{{singleCard.title}}</b></h5>
                                     <p  >
                                             {{singleCard.details}}
                                     </p>
                                </div>
                               </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container py-3">
                <div class="row justify-content-center">
                <div class="col-lg-8 benefit">
                    <div class="card p-2">
                        <h6>How your Business Can Benefit</h6>
                        <p> {{singleCard.benefit}}</p>
                    </div>
                </div>
                <div class="col-lg-12 text-end">
                    <div class="btn btn-danger" @click="hidden">Close View</div>
                </div>
            </div>
            </div>
        </div>

        <!-- Main Footer -->
        <Footer/>
    </div>
</template>
<script>

import Footer from "../components/Footer.vue"

export default {
    components: {
        Footer,
    },
    data() {
        return {
            isHidden: false,
            cardTitle: [
                {
                    title: "CFO Business Partnering",
                    details: `As the CEO of a rapidly growing startup or a SMB, you are faced with many challenges.
                You need someone who can help with your financial management, help your business scale up,
                act as an advisor to you and provide valuable input on key strategic decisions.
                However, there is one challenge that all CFOs face – finding the right talent for finance roles in their
                company. Finding great people who can grow along with your business is not easy. Most small business
                owners do not have a full-time CFO. They outsource their accounting work but when it comes to strategic
                financial advice, most CEOs feel like they're flying blind in making decisions that will impact their company's future.`,
                    benefit: `We solve this problem by acting as a trusted partner to CEOs and other senior leaders at fast-growing companies
                like yours. We act as a Fractional CFO - we provide expert advise and support on financial matters without taking up any full
                time resource from you or your team! Hiring a Fractional CFO is the solution for many businesses looking for strategic guidance
                from experts who understand your industry and how it fits into today's rapidly changing business landscape. You can focus on growing
                our business without worrying about what lies ahead financially!`},

                {
                    title: "Performance Insights",
                    details: ` Setting up and actioning business goals is enabled by means of getting all your business’
                stakeholders to operate in tandem. A lot of businesses struggle to find the right
                Performance Management model that works for them. Traditional Performance Management models
                are time-consuming, complex, and do not provide the insights needed to make data-driven decisions.
                Not having a well-designed and implemented Performance Management model can lead to blindspots in
                decision-making resulting in missed targets and goals, inefficiencies, and even layoffs. Designing
                and implementing a new Performance Management model can seem daunting. It's hard to know where to
                start or what steps to take.`,
                    benefit: `We assess the current state of your business’ performance reporting architecture and then
                based on your business needs, we build and design a robust Performance Management and reporting framework,
                automate it so that it runs smoothly,  based on the cadence required to make sound decisions.
                Performance Reporting enables your business to critically review revenue, costs, contribution margins by
                geographies and by customers, expenses, Unit Economics like Lifetime Customer Value (LTV) and Customer
                Acquisition costs (CAC) as an ongoing and an agile exercise as opposed to a static one. It helps with
                timely decision making and responsiveness by means of changing Resource allocation or expense budgets
                in order to implement course correction,  to maximize value-add impact to the financial performance and
                to mitigate the financial risks on account of blind-sided decisions. Performance Reporting offers the
                much needed velocity to drive change and demonstrate results. `},

                {
                    title: "KPIs, Board Packs & Dashboards",
                    details: `KPIs are the key performance indicators that each business needs to track on an ongoing basis.
                The nature of these bespoke metrics will depend largely upon what your business is trying to achieve with
                them, but they should also be tailored closely around your financial model drivers in order for it to make
                sense and provide meaningful data points at all times. The other critical problem is that most companies do
                not have a good way to measure how they're doing financially. KPIs offer insight by looking at expected future
                trends which helps businesses stay informed about their own situation so take advantage!`,
                    benefit: `Get the board's attention with impactful data stories and insights that will help drive your business
                forward. Board packs are summarized packs of detailed management reports prepared specifically for the board,
                including investors. Metrics are carefully selected and presented along with key takeaways and comments, so you
                can focus on what's important and make informed decisions. Impactful discussions using KPIs and Management packs
                Data are only possible with visual storytelling. Data visualizations therefore are a powerful tool for communicating
                complex data in an intuitive manner. They help you get your key messages across and shape up leadership decision-making
                processes, resulting in best possible outcomes. Interactivity helps dig deeper and determine why businesses performed
                the way they have, giving clear root-cause and helping alter course and take corrective actions, if need to be. `},

                {
                    title: "Financial modeling",
                    details: `Financial models with unrealistic or incorrect assumptions lead to poor forecasts and decisions being made
                by management. This is why it's critical for Financial Analysts to build accurate Financial Models from the ground up.
                Top-down forecasting (using Economic and Industry factors) and bottom-up modeling (using company specific drivers) need
                to be always balanced. Your business can not rely on one without the other! The best way to address this issue is by
                developing a financial model that is driver-based from the bottom up and uses multiple scenarios as well as sensitivity
                analysis. This will help ensure accuracy in your forecasts across different market conditions.`,
                    benefit: `Designing and developing a Financial Model that caters to the specific needs of the business is fundamental
                to meet the Financial and Extended Planning and Analysis objectives of your business. Our bottom-up and driver-based
                Financial Models that form the basic building blocks of your business are modeled which in turn drives accurate
                forecasting. A driver-based framework strengthens the model multifold by applying a holistic approach through rule-based
                relationships. For example, the increase in marketing budget leading to rise in sales and therefore leading to rise in
                support headcount and fixed Payroll costs. ` },

                {
                    title: "Budget Development & Monitoring",
                    details: `Developing and monitoring a budget can be a complex and time-consuming process. It's important to also have
                accurate data to make sound decisions, but this data is often difficult to collect and aggregate. A well-developed
                and monitored budget can help your business stay on track and make informed decisions like where to allocate your resources.`,
                    benefit: `Our budget development and monitoring solutions will take the hassle out of the process for you. We will work with
                you to understand your business goals, model, and systems so that we can provide a tailored solution that makes sense for you.
                Plus, we'll continue to monitor your budget on a monthly or quarterly basis so you always have accurate information at your fingertips.
                The goal of this process is to work with different functions, cost centers or geographies and gather the information needed for a
                full-fledged budgeting process. We help consolidate it as per your Chart Of Accounts and segmental datasets before feeding them into
                Budgeting models so they are regularly monitored depending on how often a business chooses for monitoring their budgets. `},

                {
                    title: "Rolling and Continuous Forecasts",
                    details: `Continuous Planning and Rolling Forecasts are critical for businesses as they enable them to plan ahead and make sure that
                your financial performance is optimized for changing business environments. The traditional budgeting process is static and
                inflexible. This means that it's not agile enough to respond quickly to changing business conditions, which makes it difficult
                for businesses to be proactive when they need to make changes in their budgets.
                However, traditional ways of forecasting which involve creating a static budget often do not work well because it fails to take into
                account the changing environment that your business will be operating in over time.`,
                    benefit: `A rolling forecast enables you to look at forecasts as an ongoing exercise rather than a static one which means that you can
                revise your assumptions on a monthly or quarterly basis and ensure that your business takes and adopts a value maximization behavior
                continuously. This also gives you more flexibility when making decisions and planning ahead about how much money should be allocated
                towards initiatives like marketing activities, new product development etc. You can look at the data from previous months/quarters and
                see if things have changed since then. It is also easier to adjust your business’ forecasts if strategic change or course correction is
                required in the financial plan during this process of continuous planning and rolling forecast. You can always see what’s coming up next
                quarter or next twelve months rather than having everything fixed in place until the end of year-end period comes around again.
                An added benefit is to get a head-start on the next years’ annual planning and budgeting exercise, reducing considerable time and efforts.` },

                {
                    title: "Zero-Based Budgeting",
                    details: `Most businesses are not profitable due to poor financial planning, struggle to keep track of their financial performance and most
                companies still use the traditional budgeting process. Starting from last year as the base and arriving at the current year’s potential
                allocation lacks depth in justifying the need to incur that expenditure. A lot of companies do not know or lack visibility on how much
                they should be spending on a project or task, and end up overspending. This ends up hurting their bottom line.  `,
                    benefit: `Zero-based budgeting is a more effective way of managing your finances and will help you get better results. With zero based budgeting,
                every department in your company starts with a clean slate each year. This means that they have to justify every dollar they spend this year as
                opposed to last year. The result? A leaner, meaner business that can focus on what matters most – growth! ZBB helps you track your company's finances
                so that you can make better decisions about where to spend money and how prudent each expense head needs to be managed on an ongoing basis. ` },

                {
                    title: "Cash Flow Forecasting",
                    details: `Cashflow forecasting is essential for running operations seamlessly and mitigate risks of running out of cash. The problem with traditional
                methods of cash flow management is that they are too time consuming, manual and error prone due to the lack of automation, visibility into historical
                data or the inability to compare actuals vs forecasts. Despite its importance, cash flow forecasting has historically been cumbersome and based on manual
                updates by multiple people in different departments to get an accurate picture of how much money is coming in and going out. Such manual processes and
                lack of a single source of truth increases the risk of running out of cash unexpectedly which could lead to missed payrolls or not being able to pay your
                bills on time. It also complicates management decisions like hiring more staff or investing in new equipment because you do not have reliable data about
                how much money will be coming into the business over a given period.`,
                    benefit: `By automating the cashflow forecasting and planning by capturing transactions real time from book-keeping applications,bank payments and then
                tracking all these activities in one place advanced automation workflows helps us predict receivables based on past history thereby reducing working capital
                requirement significantly while increasing collections efficiency.So businesses know exactly where they stand financially at any point during their
                fiscal year allowing them to make better-informed decisions faster than ever before!`},

                {
                    title: "Variance Analysis",
                    details: `Many companies struggle to understand and manage the financial performance of their organization. We know how important it is to have a clear
                understanding of the budget and actual performance, but variance analysis can be hard. The variance analysis process is a great way for organizations
                to evaluate actual performance against budget, identify variances, and take action to improve future results. It's not always easy to understand what's
                going on with your company's financials and the root-cause of deviations between budgeted and actual performance. `,
                    benefit: `We help you to act fast before problems get out of hand. Your business can easily monitor ongoing performance and identify opportunities for
                improvement in an easy-to-understand format that highlights variances across multiple metrics such as time periods, departments, or products/services.
                Our solution makes it easier than ever before to gain insight into key business drivers so that you can make better decisions about resource allocation
                and strategy moving forward.` },

                {
                    title: "Scenario Planning",
                    details: `Financial planning is often done in a disconnected manner where What-if scenarios are not built into the Planning models, and the results may
                not be offering complete visibility to the CFO or the CEO for decision-making. Most companies look at their financial performance from a short-term
                perspective. However, the true value of a company lies in its ability to visualize the business trajectories that maximize value accretion and sustain that over time.`,
                    benefit: `Our financial scenario planning helps you understand how changes in your business strategy affect cash flow, balance sheet and fixed costs
                as well as other metrics like net income or EBITDA. This approach allows us to identify hidden risks that may impact current performance of the
                business and make better decisions going forward. Our Solutions help users with various scenarios based on changing drivers of their businesses and
                see how this affects their future profitability and cash flows. This way they can be prepared for any situation – be it an acquisition or divestiture, new product
                launch or major competitor entry into the market etc., which could change the underlying dynamics of the business drastically causing unexpected changes
                in revenues/costs and ultimately affecting profitability. We believe that if you can understand how your business will perform under different scenarios,
                then you are better prepared for what is ahead and take timely advantage of opportunities. ` },

                {
                    title: "Long-Term Strategic planning",
                    details: `Long term strategic planning is a process that requires time and effort. It can be considered as the backbone of any business strategy, but not many
                companies have enough time to focus on it. Most businesses are in constant need of short-term solutions for their day-to-day operations. However, these same
                businesses tend to neglect long term strategies because they’re too busy with current and short term targets. There is a need for a strategic partner that can
                guide you through both, especially when it comes to making decisions on raising capital or acquiring new markets.`,
                    benefit: `We help businesses achieve their goals by helping them to plan for the long-term. Our Long term Strategic Planning solution allows small and medium
                sized companies, such as those aspiring or planning on raising institutional funding or pursuing an SPAC IPO listing in addition looking into new products/geographies
                while also making sure there is alignment between short term financial plans with strategic vision so that they can move forward constantly.
                We do all the heavy lifting while you get back to running your own business! We enable you to focus on your core competencies while we use our expertise in financial
                modeling, risk analysis and market research to develop strategies that help you achieve your goals faster than ever before.` },

            ],
            singleCard: {}
        }
    },

    methods: {
        display(card) {
            this.singleCard = card
            this.isHidden = true;

            //    this.cardTitle.forEach((value,index) => {
            //        this.singleCard.push(value);
            //        console.log(value)
            //        console.log(index)
            //    });
        },
        hidden() {
            return this.isHidden = false
        }
    },

}
</script>
<style></style>
