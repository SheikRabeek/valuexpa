<template lang="">
    <div>
        <div class="hero-img-4">
           <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8">
                        <h2><b>Finance Processes Managed Services</b></h2>
                        <p><b>Exploit efficiencies from streamlining your your Business Finance Processes, manage people and process risks better</b></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="service-wrapper-2">
            <h3 class="pt-4 siteblue mb-2"><b>Finance Processes Managed Services </b></h3>
        </div>
        <div class="container-fluid services-details">
            <div class="">

                <div class="row justify-content-center align-items-stretch">
    <div class="col-lg-6 bg-light left-service py-5">
        <div class="service-wrapper-2">
            <h4 class="siteblue"><strong>Streamline Business Finance Processes for Efficiency and Risk Mitigation</strong></h4>
            <p>
                Your business is growing steadily, but the complexity of your finance processes is becoming more difficult to manage.
                Full-cycle accounting tasks regularly are at risk of process continuity, apart from talent crunch and the lack of a
                readily-available skilled workforce. As a CFO, you are stifled by operational tasks that slow down growth and impact your ability to scale.
            </p>
            <p>
                This is where our Finance Processes Managed Services can make a difference. Rather than having your team handle these processes internally,
                you bring in a specialized partner who can manage them more efficiently. This shift allows you to focus on driving business strategy,
                while your finance processes are handled smoothly in the background.
            </p>
        </div>
    </div>

    <div class="col-lg-6 right-service text-light">
        <div class="py-5 service-wrapper-2">
            <div class="col-lg-10">
                <h4><strong>The Power of Outsourcing for Efficiency</strong></h4>
                <p>
                    Many organizations encounter similar challenges when managing finance operations in-house. It is costly, complex, and exposes you to risks.
                    However, outsourcing these tasks to a managed services provider can not only streamline operations but also unlock greater returns.
                </p>
                <p>
                    Now, think about this: Instead of spending hours consolidating finance data, you rely on experts who can manage your full-cycle accounting processes,
                    including accounting, Revenue Recognition, Receivables, Payables, Month-end close, and financial reporting effortlessly.
                    Tap into a team of experts who are skilled in popular ERPs, accounting software, and integrations. Your finance team can now focus on strategic
                    initiatives that fuel future growth.
                </p>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-6 right-service text-light">
        <div class="py-5 service-wrapper-2">
            <div class="col-lg-10">
                <h4><strong>The Benefits of Managed Services</strong></h4>
                <p>
                    <strong>Enhanced ROI:</strong> Reduce costs while improving the speed and accuracy of finance processes.
                </p>
                <p>
                    <strong>Strategic Prioritization:</strong> Free up your bandwidth to focus on long-term strategic business goals.
                </p>
                <p>
                    <strong>Seamless Execution:</strong> Rely on a dedicated team of experts ensuring flawless processes,
                    in line with best practices and compliance.
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-6 bg-light left-service py-5">
        <div class="service-wrapper-2">
            <h4 class="siteblue"><strong>How You Can Benefit</strong></h4>
            <p>
                At ValueXPA, we have over two decades of experience in helping businesses optimize their finance processes.
                Whether it's outsourcing a targeted scope of work, managing an entire finance function, or building a Centre of Excellence
                – Global capability centres, our solutions are designed to centralize and improve your operations.
                This results in not just cost savings but also enhanced performance through integrated processes.
            </p>
            <p>
                We don’t just take over your finance functions—we refine and elevate them. Our playbook guarantees smooth execution, governance,
                and a commitment to high-quality service, ensuring that your business is always operating at peak efficiency.
            </p>
            <p>
                Outsourcing with Finance Processes Managed Services is not just about relieving your team of administrative burdens;
                it’s about empowering your business to focus on innovation and growth, with the confidence that your finance operations are in expert hands.
            </p>
        </div>
    </div>
</div>

        </div>
        </div>
        <div class="container">
            <h4 class="text-center py-5 siteblue"><b>Advantages of Finance Process Managed Services  </b></h4>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="true" aria-controls="collapseExample">
                        <span>Realize tangible Cost efficiencies that directly impact your bottom line</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse show" id="collapseExample">
                    <div class="card card-body  advantage-content">
                    <p> Exploit the power of establishing Shared Services Centers of excellence to drive greater efficiencies.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 ">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample1" aria-expanded="true" aria-controls="#multiCollapseExample1">
                        <span>Ensure better Business Continuity and Risk management</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample1">
                    <div class="card card-body  advantage-content">
                    <p>Manage risks on account of  people or Processes better through a well-rounded Continuity plan.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample3" aria-expanded="true" aria-controls="#multiCollapseExample3">
                        <span>Better Talent Management</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample3">
                    <div class="card card-body  advantage-content">
                    <p>Manage talent pool better in terms of Attraction, Training, Retention and Aspiration Management.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12  col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample4" aria-expanded="true" aria-controls="#multiCollapseExample4">
                        <span>Resourcing Flexibilities </span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample4">
                    <div class="card card-body  advantage-content">
                    <p> Complete flexibility in internal Resourcing, team ramp up and Scaling decisions.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample5" aria-expanded="true" aria-controls="#multiCollapseExample5">
                        <span>Structured Service Models backed by Playbooks</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample5">
                    <div class="card card-body  advantage-content">
                    <p>Well-defined SLA based Services Models and Playbooks from deep experience working with multiple clients.</p>
                    </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="container-fluid section-1 py-5">
            <div class="container">
                <div class="row justify-content-center align-items-center service-wrapper">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 card-row my-2   flex-column d-flex align-items-stretch" v-for="(card,index) in cardTitle" :key="card">
                       <div :class="index % 2 === 0 ? 'bg-light text-center py-3' : 'main-card text-center py-3'" id="navbar-example2" >
                            <img src="/img/icon-problem.png" alt="" width="40">
                            <p>{{card.title}}</p>
                            <ul class="nav nav-pills">
                                <li class="nav-item mx-auto btn btn-secondary ">
                                <a class="nav-link text-light" href="#scrollspyHeading1" @click="display(card)">View Details</a>
                                </li>
                            </ul>
                       </div>
                    </div>
                </div>
            </div>
        </div>
        <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-offset="0" class="scrollspy-example" tabindex="0" v-show="isHidden" >
            <h4 id="scrollspyHeading1"></h4>
            <div class="card mb-3 py-3">
                <div class="row g-0 justify-content-center align-items-center">
                    <div class="d-flex justify-content-center" style="max-width: 440px;" >
                        <div class="card-img">
                                <img src="img/why-us-hero.png" class="img-fluid rounded-start" alt="...">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-12 col-lg-4 ">
                        <div class="about-text">
                               <div class="why-us">
                                    <div class="card-body">
                                    <h5 class="card-title text-end py-3"><b>{{singleCard.title}}</b></h5>
                                     <p  >
                                             {{singleCard.details}}
                                     </p>
                                </div>
                               </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container py-3">
                <div class="row justify-content-center">
                <div class="col-lg-8 benefit">
                    <div class="card p-2">
                        <h6>How your Business Can Benefit</h6>
                        <p> {{singleCard.benefit}}</p>
                    </div>
                </div>
                <div class="col-lg-12 text-end">
                    <div class="btn btn-danger" @click="hidden">Close View</div>
                </div>
            </div>
            </div>
        </div>

        <!-- Main Footer -->
        <Footer/>
    </div>
</template>
<script>

import Footer from "../components/Footer.vue"

export default {
    components: {
        Footer,
    },
    data() {
        return {
            isHidden: false,
            cardTitle: [
                {
                    num: '01', title: "Revenue Operations",
                    details: `Revenue cycle management is one of the critical activities in Saas businesses and on account of the requirements mandated by ASC 606.
                The new ASC 606 guidelines for revenue recognition have made it difficult for businesses to accurately recognize revenue, especially in cases where subscription revenue is involved.  This can lead to inaccurate financial statements and missed Revenue opportunities. The new guidelines present a challenge for many companies who are struggling to determine how to apply them specifically to their business. Without expert help, it can be difficult to ensure that all revenue is captured and recognized correctly.`,
                    benefit: `Our team has the experience and capabilities necessary to help your business comply with the ASC 606 guidelines for revenue recognition. We will work with you to review all contracts in detail, identify tenure and terms, and determine performance obligations. We will also handle Salesforce CRM opportunity bookings and ensure that the right finance fields are captured for recurring and non-recurring revenues. With our help, you can rest assured that your revenue recognition process is accurate and compliant with ASC 606.`
                },

                {
                    num: '02', title: "Controller’s Office Functions",
                    details: `The controller's office is a critical function, but it can be hard to keep up with all the demands from other functions of your business such as operations, HR, Sales and Marketing as well as keep up with the latest trends and technologies. `,
                    benefit: `Controller’s office comprising standard sub-functions such as bookkeeping, procure to pay, order to cash, quote to cash processes automation and driving operational and cost efficiency through SLA-driven managed services has time and again significantly augmented the capabilities of the function.
                Financial Controller's office function Support provides a comprehensive suite of services that automate key processes and drive operational and cost efficiencies. Our team of experts will work with you to create an SLA that meets your specific needs and help you get the most out of your controller's office function.`},
                {
                    num: '02', title: "Month-End Close Services ",
                    details: `Month-end closing is a complex and time-consuming process which requires reconciliation and follows a custom checklist for each business. Accountants spend the bulk of their time reviewing and making adjustment entries making sure every exception is resolved before posting to accountancy.
                However, without the help of automation in the process, month-end closing can be extremely time-consuming, cumbersome and complex. This can lead to delays in financial reporting and decision-making.  The lack of a single source for data, makes it difficult to ensure accuracy. In addition, absence of a robust workflow automation or version control which means that any discrepancies need to be traced, root-cause is to be analyzed and resolved. Traditional tools significantly hinder the process due to inability to handle data from various sources, running rule-based checks for large data sets and so on.
                `,
                    benefit: `The process typically includes four steps which include identifying where data comes from; making sure there isn't any overlap between transactions across these various ledgers before finally reconciling them all at once after and then ensuring that the financial reports are accurately representing business performance.
                Analytical automation and Custom Reconciliation Solutions can help you overcome these challenges by automating the reconciliation process starting with bringing the data from various sources to a single platform, reconcile differences between General Ledger and sub-ledgers, external sources like Bank transactions and Foreign exchange rates, and Internal Information such as Inter-company transactions.
                Designing and developing workflow automation is a great way to streamline your month-end processes. Built-in checks, rule-based exceptions reporting allows your Finance team to have the flexibility of repeating certain tasks regularly or on demand while also automatically marking where accountants and controllers need to direct their efforts to handle exceptions. This eliminates the need for intervening in a much larger set of transaction data and narrows down manual efforts in handling exceptions only. Reduction in manual efforts directly impacts your ROI and drives greater efficiency into the process.`},

            ],
            singleCard: {}
        }
    },

    methods: {
        display(card) {
            this.singleCard = card
            this.isHidden = true;

            //    this.cardTitle.forEach((value,index) => {
            //        this.singleCard.push(value);
            //        console.log(value)
            //        console.log(index)
            //    });
        },
        hidden() {
            return this.isHidden = false
        }
    },

}
</script>
<style></style>
