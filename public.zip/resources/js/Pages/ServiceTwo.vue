<template lang="">
    <div>
        <div class="hero-img-3">
           <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8">
                        <h2><b>Advanced Analytics and Business Intelligence</b></h2>
                        <p><b>Leverage your business' data-as-an-asset and Advanced Analytics to create an edge that has never been seen before</b></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="service-wrapper-2">
            <h3 class="pt-4 siteblue mb-2"><b>Advanced Analytics and Business Intelligence</b></h3>
        </div>
        <div class="container-fluid services-details">
            <div class="">

                <div class="row justify-content-center align-items-stretch">
    <div class="col-lg-6 bg-light left-service py-5">
        <div class="service-wrapper-2">
            <h4 class="siteblue"><strong>Transforming Data into a Strategic Asset for Sharp Business Insights</strong></h4>
            <p>
                As a CFO, you are constantly dealing with data scattered across different systems. Your team spends countless hours trying to piece together
                financial reports, pulling data from one system after another, just to get a clear picture of business performance. Meanwhile, critical decisions
                are delayed, and opportunities are missed because your team is tied up in manual tasks.
            </p>
        </div>
    </div>

    <div class="col-lg-6 right-service text-light">
        <div class="py-5 service-wrapper-2">
            <div class="col-lg-10">
                <h4><strong>Sound familiar? You are not alone.</strong></h4>
                <p>
                    This is the reality for many finance teams today. They are bogged down by outdated processes and disconnected systems, spending more time
                    gathering data than analyzing it. In fact, studies show that nearly three-fourths of finance professionals find themselves in this very
                    situation—missing out on the chance to provide deeper insights that could drive real business growth.
                </p>
                <p>
                    But what if things were different? What if your finance team could shift from simply reacting to problems to steering the company forward
                    with real-time, data-driven insights?
                </p>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-6  left-service py-5  text-light">
        <div class="service-wrapper-2">
            <h4><strong>Breaking Down the Silos</strong></h4>
            <p>
                What if, instead of wasting time hunting for information, your data flowed seamlessly across every department—finance, operations, sales,
                and beyond? No more silos. No more delays. Just one unified view of your business’ performance, available whenever you need it.
            </p>
            <p>
                This is where Advanced Analytics and Business Intelligence (BI) come into play. By integrating all your data into a single source of truth,
                you can finally get ahead of the curve. Instead of reacting to what has already happened, your finance team becomes proactive—anticipating risks,
                spotting opportunities, and making informed decisions in real time.
            </p>
        </div>
    </div>

    <div class="col-lg-6 bg-light right-service">
        <div class="py-5  service-wrapper-2">
            <div class="col-lg-10">
                <h4  class="siteblue"><strong>How You Can Benefit</strong></h4>
                <p>
                    Picture this: Instead of your team spending hours manually compiling reports, Analytical Process Automation takes over those repetitive tasks,
                    freeing up your people to focus on what really matters—providing insights that move the business forward. With Business Intelligence tools, your
                    finance team now has access to live dashboards that show exactly how the company is performing. No more waiting for end-of-month reports.
                </p>
                <p>
                    Now, instead of struggling with outdated systems, your company has turned its data into a strategic asset. Finance isn’t just crunching numbers
                    anymore—they are leading the charge. As your business grows, these insights help you stay one step ahead, turning challenges into opportunities
                    and making decisions with confidence.
                </p>
                <p>
                    When you break down silos and harness the full power of your data, your business doesn’t just survive—it thrives. With Advanced Analytics and
                    Business Intelligence, you can finally unlock the potential hidden within your data, turning it into the engine that drives your company’s success.
                    What does this mean for you? Faster decision-making to partner with the CEO and the Board. Better collaboration across departments. And the ability
                    to use your data not just to track performance, but to drive it.
                </p>
            </div>
        </div>
    </div>
</div>

            </div>
        </div>
        <div class="container">
            <h4 class="text-center py-5 siteblue"><b>Advantages of Advanced Analytics and Business Intelligence  </b></h4>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="true" aria-controls="collapseExample">
                        <span>Driving ROI from Advanced Analytics Solutions</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse show" id="collapseExample">
                    <div class="card card-body  advantage-content">
                    <p> Advanced Analytics Solutions are designed and developed for repeatability, hence drives significant ROI from FInance Function.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 ">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample1" aria-expanded="true" aria-controls="#multiCollapseExample1">
                        <span>Gaining Edge through Automated Workflows and Centralised Data Repositories</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample1">
                    <div class="card card-body  advantage-content">
                    <p>Design , develop and deploy custom solutions that act as key enablers to delivering high-impact XP&A to businesses.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample3" aria-expanded="true" aria-controls="#multiCollapseExample3">
                        <span>Maximizing business benefits from Data</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample3">
                    <div class="card card-body  advantage-content">
                    <p>Leverages data-as-as-asset and exploits its full potential in Management decision-making.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12  col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample4" aria-expanded="true" aria-controls="#multiCollapseExample4">
                        <span>Generating Differentiated Insights </span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample4">
                    <div class="card card-body  advantage-content">
                    <p> Gives rise to differentiated insights that combine Operational and Financial metrics, that were unavailable so far. </p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 col-md-8">
                    <div class=" text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample5" aria-expanded="true" aria-controls="#multiCollapseExample5">
                        <span>Disrupting your Reporting Model</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample5">
                    <div class="card card-body  advantage-content">
                    <p> Significantly augments your Reporting Cadence and timely Insights.  </p>
                    </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="container-fluid section-1 py-5">
            <div class="container">
                <div class="row justify-content-center align-items-center service-wrapper">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 card-row my-2   flex-column d-flex align-items-stretch" v-for="(card,index) in cardTitle" :key="card">
                       <div :class="index % 2 === 0 ? 'bg-light text-center py-3' : 'main-card text-center py-3'" id="navbar-example2" >
                            <img src="/img/icon-problem.png" alt="" width="40">
                            <p>{{card.title}}</p>
                            <ul class="nav nav-pills">
                                <li class="nav-item mx-auto btn btn-secondary ">
                                <a class="nav-link text-light" href="#scrollspyHeading1" @click="display(card)">View Details</a>
                                </li>
                            </ul>
                       </div>
                    </div>
                </div>
            </div>
        </div>
        <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-offset="0" class="scrollspy-example" tabindex="0" v-show="isHidden" >
            <h4 id="scrollspyHeading1"></h4>
            <div class="card mb-3 py-3">
                <div class="row g-0 justify-content-center align-items-center">
                    <div class="d-flex justify-content-center" style="max-width: 440px;" >
                        <div class="card-img">
                                <img src="img/why-us-hero.png" class="img-fluid rounded-start" alt="...">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-12 col-lg-4 ">
                        <div class="about-text">
                               <div class="why-us">
                                    <div class="card-body">
                                    <h5 class="card-title text-end py-3"><b>{{singleCard.title}}</b></h5>
                                     <p  >
                                             {{singleCard.details}}
                                     </p>
                                </div>
                               </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container py-3">
                <div class="row justify-content-center">
                <div class="col-lg-8 benefit">
                    <div class="card p-2">
                        <h6>How your Business Can Benefit</h6>
                        <p> {{singleCard.benefit}}</p>
                    </div>
                </div>
                <div class="col-lg-12 text-end">
                    <div class="btn btn-danger" @click="hidden">Close View</div>
                </div>
            </div>
            </div>
        </div>

        <!-- Main Footer -->
        <Footer/>
    </div>
</template>
<script>

import Footer from "../components/Footer.vue"

export default {
    components: {
        Footer,
    },
    data() {
        return {
            isHidden: false,
            cardTitle: [
                {
                    title: "Analytical Process Automation (APA)",
                    details: `Businesses are constantly trying to improve their efficiency and reduce costs. Yet, many businesses
                still rely on manual processes for the analysis of data and reporting. By automating these tasks, businesses
                can quickly identify trends and signals in data that may otherwise go unnoticed and unutilised.
                Manual analytical processes are time consuming, error prone and often require repeated effort from multiple
                resources which leads to delays in identifying key insights or taking actionable steps based on those insights.
                Additionally, manual reporting is not scalable as it becomes increasingly difficult to manage with exponentially
                growing volume of data to process. Businesses need to increase their efficiency by utilizing technology tools to
                drive significant efficiencies into their process, which is otherwise an intensive manual effort. By automating
                your workflow you will save time and money while ensuring accuracy across all departments involved with the process.`,
                    benefit: `Analytical Process workflow development and Reporting Automation through products such as Alteryx and other similar open-source products enable your business to leverage technology tools to drive significant efficiencies into the process, which is otherwise an intensive manual effort. Each business’s process and data architecture is blended, transformed and modeled to ensure seamless repeatability and sustainability of the process.
                Our process automation solution enables you to leverage technology tools such as Alteryx and similar products and significantly increase your business’s efficiency by reducing the need for manual efforts required for analyzing large volumes of data or creating reports across various sources of information at different timescales. We have developed a set of proprietary algorithms and workflows that transform your data which is modeled for repeatability of the analytical process, giving you real-time insights needed for Strategic and Operational decision-making.
                We offer custom solutions that blend with your data architecture, combine modeling, transformation and automation development services into one package deal at a fraction of what it would cost if you were to build each component separately. Our solutions enable our clients' business process re-engineering initiatives by delivering workflows designed around specific requirements so they can achieve higher levels of performance than ever before possible within the organization's existing infrastructure.  In addition, your business will benefit from quicker planning cycles and respond quickly to events.`},

                {
                    title: "Business Intelligence & Analytics",
                    details: ` Data you have is only valuable if you can extract meaning from it. but it's really hard to make sense of all the information that you have. Most businesses are drowning in data and do not know how to use it effectively.  Building insightful visualizations and reports based on business intelligence frameworks help make better decisions. Without such reporting systems, your business is missing out on valuable insights and finance teams are unable to tell accurate and meaningful stories with their data.`,
                    benefit: `Finance data analytics and Insights is the best way to get your company's financial information in one place. We offer real-time analytics, insights, agile planning and rolling forecasts so that you can make better decisions. Our services will help you with everything from data collection to data analytics.

Data analytics and insights are generated from a single source of truth for financial planning, forecasting, and decision-making. We provide real-time analytics and Insights to streamline your business processes while providing strategic insight into your company's future.

Our solutions help businesses create visually stunning dashboards and reports using creative visualization tools. You'll be able to easily get answers to your deeper questions like what was the incremental sales generated on account of fresh sales and marketing budget in the period before and  how much  was the contribution margin by Customer sales channel last quarter and so on. Your team will be empowered by our BI  Services as they use it every day for planning, reporting & more!

Our business intelligence solutions help businesses turn their numbers into actionable insights through automated reporting, insight generation through KPIs and data visualization contribute to effective data storytelling. We help companies make better decisions by turning raw numbers into meaningful reports that provide quick answers when needed. We also allow them to share this information throughout the organization so everyone has access at any time from anywhere. This means employees always have up-to-date company financials, customer activity and other key metrics right at their fingertips – helping them do more with less effort! Keeping your finger on the pulse of your business is easier than ever before with our powerful yet.
`},

            ],
            singleCard: {}
        }
    },

    methods: {
        display(card) {
            this.singleCard = card
            this.isHidden = true;

            //    this.cardTitle.forEach((value,index) => {
            //        this.singleCard.push(value);
            //        console.log(value)
            //        console.log(index)
            //    });
        },
        hidden() {
            return this.isHidden = false
        }
    },

}
</script>
<style></style>
