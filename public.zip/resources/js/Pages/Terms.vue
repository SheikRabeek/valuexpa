<template lang="">
    <div>
        <div class="container-fluid about-banner">
            <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8 text-light">
                        <h2><b>Terms and Conditions</b></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container py-5">
            <div class="row g-0 justify-center align-items-center">
                <div class="col-md-12">
                    <div class="about-text">
                        <h2>About Us</h2>

                        <b>FINNACER TECHNOLOGIES LLP, </b><span style="font-weight: 400;">(“</span><b>We</b><span style="font-weight: 400;">”/ “</span><b>Us</b><span style="font-weight: 400;">”/ “</span><b>Our</b><span style="font-weight: 400;">”) is limited liability partnership incorporated in India and is engaged in the business of providing financial consultancy services/solutions (“</span><b>Services</b><span style="font-weight: 400;">”) to its clients/users (who shall hereinafter be referred to as&nbsp;“</span><b>You</b><span style="font-weight: 400;">”, “</span><b>Your</b><span style="font-weight: 400;">” “</span><b>User</b><span style="font-weight: 400;">”&nbsp;as applicable), The Services shall be rendered either through its website at </span><b>www.www.valuexpa.com</b><span style="font-weight: 400;"> (“</span><b>Website</b><span style="font-weight: 400;">”) or through various mobile applications that are made available to you (“</span><b>Applications</b><span style="font-weight: 400;">”) from time to time (the Website and Application shall be collectively referred to as “</span><b>Platform</b><span style="font-weight: 400;">”).</span>
                        <span style="font-weight: 400;">This document describes and governs the terms and conditions (“</span><b>Terms</b><span style="font-weight: 400;">”) with respect to the Services related information made available through the Platform.</span>
                        <span style="font-weight: 400;">YOU ACKNOWLEDGE AND AGREE THAT BY BROWSING OR USING THE PLATFORM, YOU HAVE AGREED TO BE BOUND BY THESE TERMS AND CONDITIONS AND ANY ADDITIONAL TERMS THAT APPLY.&nbsp;</span>
                        <span style="font-weight: 400;">Please note that We reserve the right to revise this Terms at any time by posting an update to this page. Your continued use of the Platform or Services following the posting of changes to these Terms will mean you accept those changes. If you do not agree with any of the Terms, you must not continue to use the Platform. We reserve the right, in its sole discretion, to determine if you have violated the Terms and to take any action it deems appropriate. You acknowledge that We shall have the right to terminate your access to the Platform or Services for violations of any of these rules, including repeat infringement of copyrights.</span>

                        <h2>Accessing the Platform</h2>

                        <span style="font-weight: 400;">It is your responsibility to ensure that you have made all necessary arrangements in order to access the Platform. We shall not be responsible for any telephone bills, internet charges or any other costs incurred by you in order to access the Platform.&nbsp;</span>
                        <span style="font-weight: 400;">You are responsible for ensuring that all persons who access the Platform through your internet connection are aware of these Terms and the other applicable terms and conditions/policies mentioned, and comply with them.&nbsp;</span>
                        <span style="font-weight: 400;">By using the Platform, you represent and warrant that:&nbsp;</span>

                        <ul>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">You are at least 18 years old;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">You have the lawful authority and capacity to contract and be bound by these Terms;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">If you are accepting these Terms on behalf of a company, limited liability partnership or other legal entity, you have the authority to bind such entity to these Terms and, in such event, “you” and “your” as used in these Terms shall refer to such entity; and</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">You will comply with all applicable laws and regulations.</span></li>
                        </ul>

                        <span style="font-weight: 400;">These Terms are subject to change at any time without notice. To make sure you are aware of any changes, please </span><span style="font-weight: 400;">review</span><span style="font-weight: 400;"> these Terms periodically. Continued use of the Platform after any such changes shall constitute your consent to such changes.</span>

                        <h2>Use of Services </h2>

                        <p><span style="font-weight: 400;">Vide these Terms, We grant you a limited, personal, non-exclusive, non-transferrable and non-sub licensable right to use the Platform, solely for your own personal, non-commercial use, subject to the Terms contained herein. </span><span style="font-weight: 400;">Your access and use of the Platform</span><span style="font-weight: 400;"> shall be subject to the following representations and warranties:</span></p>

                        <ol style="list-style:lower-alpha">
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">You </span><span style="font-weight: 400;">may</span><span style="font-weight: 400;"> only access the Platform using authorized and lawful means;&nbsp;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">We shall not be liable for any failure or default to provide access to the Platform on account of any failure or delay by you to register with the Platform for such access or due to any other reasons whatsoever;&nbsp;</span></li>
                        </ol>

                        <p><span style="font-weight: 400;">Any configuration or set up of the devices for access to the Platform shall be your sole responsibility.&nbsp;&nbsp;</span></p><p><span style="font-weight: 400;">We </span><span style="font-weight: 400;">collect, store, process and use your information in accordance with Our </span><a href="/privacy-policy/"><span style="font-weight: 400;">Privacy Policy</span></a> <b>(“Privacy Policy”)</b><span style="font-weight: 400;">. By using the Platform and/or availing the Services, you will be required to provide your Personal Information </span><i><span style="font-weight: 400;">(as defined in the Privacy Policy)</span></i><span style="font-weight: 400;">.</span></p><p><span style="font-weight: 400;">You will not </span><span style="font-weight: 400;">take</span><span style="font-weight: 400;"> any action that interferes with, degrades or adversely affects </span><span style="font-weight: 400;">Us </span><span style="font-weight: 400;">and/or the Platform.</span></p><p><span style="font-weight: 400;">You </span><span style="font-weight: 400;">will</span><span style="font-weight: 400;"> not use the Platform in a manner that: (i) is prohibited by any law or regulation, or facilitates the violation of any law or regulation; or (ii) will disrupt a third parties’ similar use; (iii) will violate or tamper with the security of the Platform.</span></p><p><span style="font-weight: 400;">You will not use the Platform, or any portion thereof, to transmit, publish, post, upload, distribute or disseminate any inappropriate, harassing, abusive, defamatory, libelous, obscene, illegal or deceptive content.</span></p><p><span style="font-weight: 400;">You will not attempt to gain unauthorized access to any information connected to the </span><span style="font-weight: 400;">Platform</span><span style="font-weight: 400;">/Services, including but not limited to, names, addresses, phone numbers, or email addresses, copying copyrighted text, through hacking, or any other means, or obtain or attempt to </span><span style="font-weight: 400;">obtain</span><span style="font-weight: 400;"> any materials or information through any means not intentionally made available to you.</span></p><p><span style="font-weight: 400;">You shall be solely responsible for: (i) procuring and maintaining your network connections and </span><span style="font-weight: 400;">telecommunications</span><span style="font-weight: 400;"> links, and (ii) all problems, conditions, delays, delivery failures and all other loss or damage arising from or relating to your network connections or telecommunications links or caused by the internet.</span></p>

                        <h2>Intellectual Property Rights</h2>

                        <p><span style="font-weight: 400;">The trademarks, service marks, and logos used and displayed by Us, in any manner on the Platform or in any of the content are Our registered or unregistered proprietary rights worldwide. Further the trademarks, service marks, and logos used and displayed belonging to the Platform’s users, advertisers, or third parties as displayed on the Platform are the owned by such users, advertisers, or third parties and are hereby only licensed to the Platform for the limited purpose of displaying the same.</span></p><p><span style="font-weight: 400;">Such propriety trademarks or logos belonging to Us or our partners, contractors, affiliates, advertisers, any users or third parties are protected pursuant to applicable laws. All rights are reserved and you may not alter or obscure the such proprietary mark or name or logos, or link to them without Our prior approval or the prior approval from respective owners of such proprietary mark.</span></p><p><span style="font-weight: 400;">All legal rights including intellectual property rights, title and interest in and to the Platform including but not limited to user interface and the applications and codes used to implement the Platform, Services, vests with Us. The Platform contains proprietary and confidential information. You agree that you shall not use such proprietary information and other materials provided or used by the Platform, in any way whatsoever except for use of the Platform and the Service in accordance with these Terms. No portion of the Platform shall be reproduced in any form by you.</span></p>

                        <h2>Indemnification</h2>

                        <p><span style="font-weight: 400;">By</span><span style="font-weight: 400;"> accepting these Terms&nbsp; and using the Platform and availing the Services, you agree that you shall defend, indemnify and hold </span><span style="font-weight: 400;">Us</span><span style="font-weight: 400;">, our </span><span style="font-weight: 400;">directors, employees, shareholders, </span><span style="font-weight: 400;">officers and other representatives&nbsp; harmless from and against any and all claims, costs, damages, losses, liabilities and expenses (</span><span style="font-weight: 400;">including</span><span style="font-weight: 400;"> attorneys’ fees and costs) arising out of or in connection with: </span><span style="font-weight: 400;">(i) </span><span style="font-weight: 400;">your violation or breach of these Terms&nbsp; any applicable law or regulation</span><span style="font-weight: 400;">; </span><span style="font-weight: 400;">(</span><span style="font-weight: 400;">ii) any loss or injury to Our representatives resulting from or attributable to your acts or omissions;</span><span style="font-weight: 400;"> (iii) </span><span style="font-weight: 400;">misuse of the Platform</span><span style="font-weight: 400;">; (iv) your violation of any rights of any third party; or (vi) </span><span style="font-weight: 400;">any and all third-party claims based upon (A) the content of any communications transmitted by you; and/or (B) transactions undertaken by you.</span></p>

                        <h2>Limitation of Liability</h2>

                        <p><span style="font-weight: 400;">To the maximum extent permitted by law, We shall provide the information relating to the Services without warranties, guarantees or representations. We shall assume no responsibility and shall not be liable for any loss or damage which may affect your computer equipment or other equipment/property arising out of your use of the Platform or access to or browsing of the Platform.</span></p><p><span style="font-weight: 400;">Under no circumstances We will be liable to you for any damages whatsoever (including, without limitation, incidental, reliance, or consequential, or special damages whether or not foreseen, lost profits, or damages resulting from lost data or business interruption) on account of your use, misuse, or reliance on the information relating to Services, provided on the Platform. This limitation of liability shall apply to prevent recovery of direct, indirect, incidental, consequential, special, exemplary, or punitive damages arising from any claim relating to this Terms or the subject matter hereof, whether such claim is based on warranty, contract, tort (including negligence), or otherwise any other legal theory even if We have been advised of the possibility of such damages.&nbsp;</span></p><p><span style="font-weight: 400;">We explicitly disclaim any and all liability for any the following:</span></p>

                        <ol style="list-style:lower-alpha">
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">errors, mistakes or inaccuracies of the content displayed on the Platform;&nbsp;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">personal injury or property damage of any nature whatsoever, resulting from use of the Platform or Services for any alleged or actual damages or loss of valuables;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">the acts or omissions of our representatives performing Services on our behalf;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">any failure or delay in the Services; and</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">any loss or damage arising out of your failure to adhere to your obligations under the Terms.</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">user content or the defamatory, offensive, or illegal conduct of any third party with respect to any content on the Platform.</span></li>
                        </ol>

                        <p><span style="font-weight: 400;">You agree not to use the Platform for any commercial or business purposes, and acknowledge that we have no liability to you for any loss of profit, loss of business, business interruption or loss of business opportunity.&nbsp;</span></p><p><span style="font-weight: 400;">YOU ACKNOWLEDGE AND AGREE THAT THE ENTIRE RISK ARISING OUT OF YOUR USE OF THE PLATFORM AND/OR AVAILING ANY SERVICES REMAINS SOLELY WITH YOU.</span></p>

                        <h2>Linking to the Platform</h2>

                        <p><span style="font-weight: 400;">You may link to our home page, provided that you do so in a way that is fair and legal and does not damage our reputation or take advantage of it.&nbsp;</span></p><p><span style="font-weight: 400;">You must not establish a link in any such way that suggests a form of association, approval or endorsement with or by Us where none exists.&nbsp;</span></p><p><span style="font-weight: 400;">You must not establish a link to the Platform in any website that does not belong to you.&nbsp;</span></p><p><span style="font-weight: 400;">The Platform must not be framed on any other site, nor may you create a link to any part of our Platform other than the home page.&nbsp;</span></p><p><span style="font-weight: 400;">We reserve the right to withdraw linking permissions at any time and without notice.&nbsp;</span></p><p><span style="font-weight: 400;">The website in which you are linking must comply with these terms of use in all respects.&nbsp;</span></p><p><span style="font-weight: 400;">Should you wish to make use of any of the content on the Platform other than set out above or report any complaint of abuse or misuse, please contact: </span><b>www.www.valuexpa.com</b></p>

                        <h2>Disclaimers and Warranties </h2>

                        <p><span style="font-weight: 400;">The content in the Platform is provided to you strictly on an “as is” basis.&nbsp; Notwithstanding anything contained in these Terms, We do not warrant that the Platform: (i) will perform error-free or uninterrupted, or that We will correct all or any errors or defects (ii) will operate in combination with your devices, or with any other hardware, software, systems or data not provided by Us, (iii) will meet your requirements, specifications or expectations, (iv) information/content on the Platform will be updated on a day-to-day basis.</span></p><p><span style="font-weight: 400;">We further acknowledge that it does not control the transfer of data over communications facilities, including the internet, and that the Platform may be subject to limitations, delays, and other problems inherent in the use of such communications facilities.</span></p><p><span style="font-weight: 400;">Your use of the Service includes the ability to enter into agreements and/or to make transactions electronically. You acknowledge that your electronic submissions on the Platform constitute your agreement and intent to be bound by this Terms.&nbsp;</span></p>

                        <h2>Other Conditions</h2>

                        <ol>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">All notices served by Us shall be provided via email to Your account or as a general notification on the Platform. Any notice to be provided to Us should be sent to </span><b>www.www.valuexpa.com</b><span style="font-weight: 400;"> or 44A, 9</span><span style="font-weight: 400;">th</span><span style="font-weight: 400;"> Street, A.Teresa Nagar, Chennai – 600091.&nbsp;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Our failure to enforce any provision of these Terms shall not be deemed a waiver of such provision nor of the right to enforce such provision. Our rights under these Terms shall survive any discontinuance of the access or use of the Platform.</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">These Terms together with the <a href="/privacy-policy/">Privacy Policy</a> published by us on the Platform/Services, shall constitute the entire agreement between you and Us concerning the Platform/Services.&nbsp;</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">If any provision of these Terms is held to be invalid or unenforceable, such provision shall be struck and the remaining provisions shall be enforced to the fullest extent under law.</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">You cannot assign or otherwise transfer Your obligations under the Terms, or any right granted hereunder to any third party. Our rights under the Terms are freely transferable to any third parties without the requirement of seeking Your consent.</span></li>
                            <li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">You acknowledge that Your participation on the Platform, does not make You an employee or agency or partnership or joint venture or franchise of Us.</span></li><li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">We provide these Terms so that You are aware of the terms that apply to your use of the Platform and Services. You acknowledge that, We have given You a reasonable opportunity to review these Terms and that You have agreed to them.</span></li>
                        </ol>

                        <h2>Governing Law</h2>

                        <p><span style="font-weight: 400;">These Terms, their subject matter and any non-contractual disputes or claims are governed by the Indian Laws and you agree to the exclusive jurisdiction of the courts of Chennai, India.&nbsp;</span></p><p><span style="font-weight: 400;">We reserve the right to seek injunctive, or any other equitable relief, in any courts of competent jurisdiction that, in its sole opinion, consider this to be necessary. </span></p>

                        <h2>Contact Us</h2>

                        <p><span style="font-weight: 400;">We make all best endeavors to provide You with a pleasant experience. In the unlikely event that You face any issues or You desire to share your feedback with us on the terms envisaged under these Terms or under the <a href="https://www.valuexpa.com/privacy-policy/">Privacy Policy</a>, please contact us at </span><b>www.www.valuexpa.com</b><span style="font-weight: 400;"> or email </span><a href="mailto:info@valuexpa.com"><span style="font-weight: 400;">info@valuexpa.com</span></a><span style="font-weight: 400;">.&nbsp;</span></p>

                    </div>
                </div>
            </div>
        </div>
        <Footer/>
    </div>
</template>
<script>
import Footer from "../components/Footer.vue"
export default {
    components:{
        Footer,
    }
}
</script>
<style lang="">

</style>
