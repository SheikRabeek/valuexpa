<template lang="">
    <div>
        <div class="hero-img-3">
           <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8">
                        <h2><b>Find hidden margin leakage in your supply chain — in 30 day</b></h2>
                        <p><b>A focused diagnostic for US$30–100m businesses. Delivered by ValueXPA. Powered by Fynflo - our Enabler Technology Solution</b></p>
                        <!-- <br><a href="/contact-us" class="btn btn-primary w-75 mb-3">
                        Before fixing leakage, quantify it. Request Diagnostic Overview</a> -->
                    </div>

                </div>


            </div>
        </div>

       <div class="container-fluid services-details mt-3">
    <div class="">
        <div class="row justify-content-center align-items-stretch">
            <div class="col-lg-6 bg-light left-service py-5">
                <div class="service-wrapper-2">
                    <h4 class="siteblue"><strong>Who This Is For</strong></h4>
                    <p>
                        This diagnostic is for you if:
                    </p>
                    <ul>
                        <li>Margins are under pressure</li>
                        <li>AP exceptions are increasing</li>
                        <li>Vendor disputes are common</li>
                        <li>You suspect leakage but can't quantify it</li>
                    </ul>
                    <p>
                        If you already "feel" something is wrong — this gives you the number.
                    </p>
                </div>
            </div>

            <div class="col-lg-6 right-service text-light">
                <div class="py-5 service-wrapper-2">
                    <div class="col-lg-10">
                        <h4><strong>What We Examine</strong></h4>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <strong>• Contracts & SOWs</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> Pricing structures</li>
                                    <li> Rebates</li>
                                    <li> Penalties and clauses</li>
                                </ul>
                            </li>
                            <li class="mb-2">
                                <strong>• Purchase Orders</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> Scope alignment</li>
                                    <li> Limits and thresholds</li>
                                    <li> Compliance gaps</li>
                                </ul>
                            </li>
                            <li class="mb-2">
                                <strong>• Invoices</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> Pricing mismatches</li>
                                    <li> Quantity discrepancies</li>
                                    <li> Duplicate billings</li>
                                </ul>
                            </li>
                            <li class="mb-2">
                                <strong>• Controls</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> Control breakdowns</li>
                                    <li> Points where leakage slips through</li>
                                </ul>
                            </li>
                        </ul>
                        <p class="mt-3"><em>No fishing. No generic reviews.</em></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-6 left-service py-5 text-light">
                <div class="service-wrapper-2">
                    <h4><strong>What You Get</strong></h4>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <strong>• Leakage quantification</strong>
                            <ul class="list-unstyled ms-3">
                                <li> Clear dollar impact</li>
                            </ul>
                        </li>
                        <li class="mb-2">
                            <strong>• Root-cause analysis</strong>
                            <ul class="list-unstyled ms-3">
                                <li> Why the leakage is happening</li>
                            </ul>
                        </li>
                        <li class="mb-2">
                            <strong>• Risk vendor list</strong>
                            <ul class="list-unstyled ms-3">
                                <li> Vendors with highest exposure</li>
                            </ul>
                        </li>
                        <li class="mb-2">
                            <strong>• Control gap view</strong>
                            <ul class="list-unstyled ms-3">
                                <li> What needs fixing</li>
                            </ul>
                        </li>
                        <li class="mb-2">
                            <strong>• Action roadmap</strong>
                            <ul class="list-unstyled ms-3">
                                <li> Practical, prioritized next steps</li>
                            </ul>
                        </li>
                    </ul>
                    <p class="mt-3">
                        Delivered in a format ready for CFO, CEO, or Board review.
                    </p>
                </div>
            </div>

            <div class="col-lg-6 bg-light right-service">
                <div class="py-5 service-wrapper-2">
                    <div class="col-lg-10">
                        <h4 class="siteblue"><strong>How The Diagnostic Works</strong></h4>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <strong>• Week 1</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> Data access</li>
                                    <li> Scope finalization</li>
                                </ul>
                            </li>
                            <li class="mb-2">
                                <strong>• Week 2</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> PO review</li>
                                    <li> Invoice review</li>
                                    <li> Contract review</li>
                                </ul>
                            </li>
                            <li class="mb-2">
                                <strong>• Week 3</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> Validation of findings</li>
                                    <li> Root-cause analysis</li>
                                </ul>
                            </li>
                            <li class="mb-2">
                                <strong>• Week 4</strong>
                                <ul class="list-unstyled ms-3">
                                    <li> Findings presentation</li>
                                    <li> Action roadmap walkthrough</li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
        <div class="container">
            <h4 class="text-center py-5 siteblue"><b>How Fynflo Fits & What Happens Next</b></h4>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12">
                    <div class="text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="true" aria-controls="collapseExample">
                        <span>How Fynflo Fits</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse show" id="collapseExample">
                    <div class="card card-body advantage-content">
                    <p>We use our internal system, Fynflo, to efficiently analyse PO, invoice, and contract mismatches and validate leakage patterns consistently. You are buying clarity and outcomes, not software.</p>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-2">
                <div class="col-lg-8 col-12 ">
                    <div class="text-start py-2 col-12">
                        <button class="col-lg-12 col-12 btn btn-light d-flex justify-content-between advantage color-blue" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample1" aria-expanded="true" aria-controls="#multiCollapseExample1">
                        <span>What Happens Next</span> <span class="dropdown-toggle"></span>
                        </button>
                    </div>
                    <div class="collapse multi-collapse" id="multiCollapseExample1">
                    <div class="card card-body advantage-content">
                    <p>After the diagnostic, you may choose to:</p>
                    <ul>
                        <li>Recover and fix leakage with ValueXPA</li>
                        <li>Implement ongoing monitoring using Fynflo</li>
                        <li>Enable your internal team with improved controls</li>
                    </ul>
                    <p>The diagnostic stands on its own.</p>
                    </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="container-fluid section-1 py-5">
            <div class="container">
                <div class="row justify-content-center align-items-center service-wrapper">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 card-row my-2 flex-column d-flex align-items-stretch" v-for="(card,index) in cardTitle" :key="card">
                       <div :class="index % 2 === 0 ? 'bg-light text-center py-3' : 'main-card text-center py-3'" id="navbar-example2" >
                            <img src="/img/icon-problem.png" alt="" width="40">
                            <p>{{card.title}}</p>
                            <ul class="nav nav-pills">
                                <li class="nav-item mx-auto btn btn-secondary ">
                                <a class="nav-link text-light" href="#scrollspyHeading1" @click="display(card)">View Details</a>
                                </li>
                            </ul>
                       </div>
                    </div>
                </div>
            </div>
        </div>
        <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-offset="0" class="scrollspy-example" tabindex="0" v-show="isHidden" >
            <h4 id="scrollspyHeading1"></h4>
            <div class="card mb-3 py-3">
                <div class="row g-0 justify-content-center align-items-center">
                    <div class="d-flex justify-content-center" style="max-width: 440px;" >
                        <div class="card-img">
                                <img src="img/why-us-hero.png" class="img-fluid rounded-start" alt="...">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-12 col-lg-4 ">
                        <div class="about-text">
                               <div class="why-us">
                                    <div class="card-body">
                                    <h5 class="card-title text-end py-3"><b>{{singleCard.title}}</b></h5>
                                     <p  >
                                             {{singleCard.details}}
                                     </p>
                                </div>
                               </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container py-3">
                <div class="row justify-content-center">
                <div class="col-lg-8 benefit">
                    <div class="card p-2">
                        <h6>How your Business Can Benefit</h6>
                        <p> {{singleCard.benefit}}</p>
                    </div>
                </div>
                <div class="col-lg-12 text-end">
                    <div class="btn btn-danger" @click="hidden">Close View</div>
                </div>
            </div>
            </div>
        </div>

        <!-- Main Footer -->
        <Footer/>
    </div>
</template>

<script>
import Footer from "../components/Footer.vue"

export default {
    components: {
        Footer,
    },
    data() {
        return {
            isHidden: false,
            cardTitle: [
                {
                    title: "Analytical Process Automation (APA)",
                    details: `Businesses are constantly trying to improve their efficiency and reduce costs. Yet, many businesses still rely on manual processes for the analysis of data and reporting. By automating these tasks, businesses can quickly identify trends and signals in data that may otherwise go unnoticed and unutilised. Manual analytical processes are time consuming, error prone and often require repeated effort from multiple resources which leads to delays in identifying key insights or taking actionable steps based on those insights. Additionally, manual reporting is not scalable as it becomes increasingly difficult to manage with exponentially growing volume of data to process. Businesses need to increase their efficiency by utilizing technology tools to drive significant efficiencies into their process, which is otherwise an intensive manual effort. By automating your workflow you will save time and money while ensuring accuracy across all departments involved with the process.`,
                    benefit: `Analytical Process workflow development and Reporting Automation through products such as Alteryx and other similar open-source products enable your business to leverage technology tools to drive significant efficiencies into the process, which is otherwise an intensive manual effort. Each business's process and data architecture is blended, transformed and modeled to ensure seamless repeatability and sustainability of the process. Our process automation solution enables you to leverage technology tools such as Alteryx and similar products and significantly increase your business's efficiency by reducing the need for manual efforts required for analyzing large volumes of data or creating reports across various sources of information at different timescales. We have developed a set of proprietary algorithms and workflows that transform your data which is modeled for repeatability of the analytical process, giving you real-time insights needed for Strategic and Operational decision-making. We offer custom solutions that blend with your data architecture, combine modeling, transformation and automation development services into one package deal at a fraction of what it would cost if you were to build each component separately. Our solutions enable our clients' business process re-engineering initiatives by delivering workflows designed around specific requirements so they can achieve higher levels of performance than ever before possible within the organization's existing infrastructure. In addition, your business will benefit from quicker planning cycles and respond quickly to events.`
                },
                {
                    title: "Business Intelligence & Analytics",
                    details: `Data you have is only valuable if you can extract meaning from it. but it's really hard to make sense of all the information that you have. Most businesses are drowning in data and do not know how to use it effectively. Building insightful visualizations and reports based on business intelligence frameworks help make better decisions. Without such reporting systems, your business is missing out on valuable insights and finance teams are unable to tell accurate and meaningful stories with their data.`,
                    benefit: `Finance data analytics and Insights is the best way to get your company's financial information in one place. We offer real-time analytics, insights, agile planning and rolling forecasts so that you can make better decisions. Our services will help you with everything from data collection to data analytics.

Data analytics and insights are generated from a single source of truth for financial planning, forecasting, and decision-making. We provide real-time analytics and Insights to streamline your business processes while providing strategic insight into your company's future.

Our solutions help businesses create visually stunning dashboards and reports using creative visualization tools. You'll be able to easily get answers to your deeper questions like what was the incremental sales generated on account of fresh sales and marketing budget in the period before and how much was the contribution margin by Customer sales channel last quarter and so on. Your team will be empowered by our BI Services as they use it every day for planning, reporting & more!

Our business intelligence solutions help businesses turn their numbers into actionable insights through automated reporting, insight generation through KPIs and data visualization contribute to effective data storytelling. We help companies make better decisions by turning raw numbers into meaningful reports that provide quick answers when needed. We also allow them to share this information throughout the organization so everyone has access at any time from anywhere. This means employees always have up-to-date company financials, customer activity and other key metrics right at their fingertips – helping them do more with less effort! Keeping your finger on the pulse of your business is easier than ever before with our powerful yet.`
                },
            ],
            singleCard: {}
        }
    },

    methods: {
        display(card) {
            this.singleCard = card
            this.isHidden = true;
        },
        hidden() {
            return this.isHidden = false
        }
    },

}
</script>

<style>
/* Add any additional styling you need for tables or other elements */
.table {
    margin-bottom: 0;
}

.table th {
    background-color: rgba(255, 255, 255, 0.1);
    border-color: rgba(255, 255, 255, 0.2);
}

.table td {
    border-color: rgba(255, 255, 255, 0.2);
}

.bg-light .table th {
    background-color: rgba(0, 0, 0, 0.05);
    border-color: #dee2e6;
}

.bg-light .table td {
    border-color: #dee2e6;
}
</style>
