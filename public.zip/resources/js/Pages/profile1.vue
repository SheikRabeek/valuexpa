<template lang="">
    <div>
        <div class="container-fluid about-banner">
            <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8 text-light">
                        <h2><b>About  </b></h2>
                        <h4>Karthikeyan V Raaj</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row p-4">
                <div class="col-lg-3">
                      <img src="img/boi-1.png" alt="" class=" col-12">
                      <div class=" text-center mt-2">
                            <a href=" https://www.linkedin.com/in/karthikeyanv/" target="_blank"><h2><i class="bi bi-linkedin"></i></h2></a>
                      </div>
                </div>
                <div class="col-lg-8 text-justify shadow p-3">
                    <p><b>Karthikeyan</b> comes with 18+ years experience in Management Consulting, FF&A, Business Performance Management, Management Decision support, Financial Modeling & Valuations. He has extensively worked with Tech Startups including Saas and Tech-enabled businesses, Small and Mid-sized Businesses, Not-for-Profit Organizations as Fractional CFO Partner. He has advised Founders and Business Leaders and helped in Solving Critical Financial and Strategic Business Problems including Operational and Strategic Financial Planning, enabling Business Leaders gain visibility into business’ performance and  generating ROI from Advanced Analytics and Financial Processes Offshoring. He advised Finance Transformation SMEs on migrating to cloud systems and rolling out Advanced Analytics and Business Intelligence solutions and dashboards. He further developed in-house tools and solutions to enable Management Decision Insights. </p>
                    <div class="col-lg-12 justify-content-center">
                        <p>Karthikeyan specializes in Strategic Financial Advisory, Financial Modeling, Extended Planning and Analysis, Management Reporting and Decision-Insights, Investor Readiness,  Development of KPIs and Management Dashboards, Revenue Recognition, Business Valuation and Investment Research. He is also Certified in Advanced Analytical Automation Platforms like Alteryx. </p>
                    </div>
                    <div class="col-lg-12 justify-content-center ">
                        <p>Earlier, he held leadership role at Barclays and worked on Financial Decision Support to Global CEO/ CFO and Business Leaders and pursued a deep Analytical FInance career at S&P Global. He holds an MBA from Great Lakes Institute of Management and is a qualified Engineer. </p>
                    </div>
                </div>
            </div>
            
        </div>
        <Footer/>
    </div>
</template>
<script>
    
   
    import Footer from "../components/Footer.vue"
export default {

    components:{
        Footer,
    }
}
</script>
<style lang="">
    
</style>