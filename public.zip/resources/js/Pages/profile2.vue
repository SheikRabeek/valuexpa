<template lang="">
    <div>
        <div class="container-fluid about-banner">
            <div class="container">
                <div class="row justify-center align-center text-center content-2">
                    <div class="col-lg-6 col-md-8 text-light">
                        <h2><b>About  </b></h2>
                        <h4>Srivathsan Sridharan</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row p-4">
                <div class="col-lg-3">
                      <img src="img/bio-2.jfif" alt="" class=" col-12">
                      <div class=" text-center mt-2">
                            <a href="https://www.linkedin.com/in/srivathsan296/" target="_blank"><h2><i class="bi bi-linkedin"></i></h2></a>
                      </div>
                </div>
                <div class="col-lg-8 text-justify shadow p-3">
                    <p><b>Srivathsan Sridharan </b>  is a results-oriented marketing professional and advisor, bringing over 21 years of expertise to the industry. Renowned for his focus on delivering measurable ROI, Srivathsan is the co-creator of HCL Tech's iGOVERN brand, a testament to his innovative contributions in the field.
                        </p>
                    <div class="col-lg-12 justify-content-center">
                        <p>Currently serving as a Partner at PINQUBITS, Srivathsan is dedicated to empowering companies and CxOs in scaling their businesses. His leadership roles span diverse industries, including Building Materials, Information Technology, Manufacturing, EdTech, Travel Tech (SaaS), and HR services. Notably, he served as the Program Manager for Randstad India and the Williams Formula 1 team, demonstrating his versatility and adaptability across different sectors.</p>
                    </div>
                    <div class="col-lg-12 justify-content-center ">
                        <p>Srivathsan is a prolific writer, with his research reports and articles, crafted on behalf of management, featured in reputable publications such as the Times of India, Business Standard, Hindu Business Line, and industry forums like NASSCOM.</p>
                    </div>
                    <div class="col-lg-12 justify-content-center ">
                        <p>An alumnus of prestigious institutions, Srivathsan holds degrees from IIM Calcutta, the Great Lakes Institute of Management (Chennai), and SASTRA (Thanjavur). His educational background, coupled with his extensive professional journey, underscores Srivathsan's commitment to excellence and continuous learning in the dynamic landscape of marketing and business.</p>
                    </div>
                </div>
            </div>

        </div>
        <Footer/>
    </div>
</template>
<script>


    import Footer from "../components/Footer.vue"
export default {

    components:{
        Footer,
    }
}
</script>
<style lang="">

</style>
