<template lang="">
  <div>
    <div class="container-fluid about-banner">
      <div class="container">
        <div class="row justify-center align-center text-center content-2">
          <div class="col-lg-6 col-md-8 text-light">
            <h2><b>About</b></h2>
            <h4>Ramesh Subramanian</h4>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row p-4">
        <div class="col-lg-3">
          <img src="img/image.png" alt="Ramesh Subramanian" class="col-12">
          <div class="text-center mt-2">
            <a href="https://www.linkedin.com/in/ramesh0508" target="_blank">
              <h2><i class="bi bi-linkedin"></i></h2>
            </a>
          </div>
        </div>

        <div class="col-lg-8 text-justify shadow p-3">
          <p>
            <b>Ramesh Subramanian</b> is a transformational leader & a strategic CFO with over 25
            years of international experience successfully steering world leading
            global MNCs such as FedEx, Inchcape PLC, Ericsson AB, Volex PLC as
            well as Government entities in the GCC such as Bahrain International
            Circuit (BIC) & Ras Al Khaimah Economic Zone (RAKEZ) towards greater
            efficiency and profitability. In addition, he is in multiple boards of
            diverse organizations driving their ExCo & board committees.
          </p>

          <div class="col-lg-12 justify-content-center">
            <p>
              In his illustrious career spanning over 5 countries, he has built,
              coached, and motivated high-performance multicultural teams that
              consistently deliver. He has a proven track record of driving business
              & digital transformations, innovation & growth, improving P&L
              scenarios, and implementing crucial change initiatives while
              maintaining employee & creditor loyalty and trust.
            </p>
          </div>

          <div class="col-lg-12 justify-content-center">
            <p>
              He excels in shaping business strategies and addressing growth challenges
              for growing, mature and declining businesses. Ramesh Subramanian is a
              skilled negotiator with balanced judgement, capable of steering
              consensus among core business disciplines with diverse agenda.
            </p>
          </div>

          <!-- <div class="col-lg-12 justify-content-center">
            <p>
              <b>Ramesh Subramanian</b><br>
              TRANSFORMATIONAL LEADER, INTERNATIONAL CFO/CTO/COO, BOARD MEMBER, ADVISOR<br>
              Bahrain: +97334340842<br>
              UAE: +971509893436<br>
              <a href="mailto:ramesh050866@gmail.com">ramesh050866@gmail.com</a><br>
              <a href="https://www.linkedin.com/in/ramesh0508" target="_blank">www.linkedin.com/in/ramesh0508</a>
            </p>
          </div> -->
        </div>
      </div>
    </div>

    <Footer />
  </div>
</template>

<script>
import Footer from "../components/Footer.vue"

export default {
  components: {
    Footer,
  },
}
</script>

<style lang="">
</style>
