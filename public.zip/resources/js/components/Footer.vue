<template lang="html">

    <div>
        <ContactFooter/>
        <div class="container-fluid contact-footer-2">
            <div class="container py-5 my-4">
                <div class="row justify-content-evenly">
                    <div class="col-lg-5 text-light">
                        <p><b>About Us</b></p>
                        <i>ValueXPA is a Global, technology-enabled finance partner working with small and mid-sized businesses. We support CEOs, and CFOs with decision-ready financial insights, strong reporting discipline, and reliable finance execution —helping organisations strengthen control, improve clarity, and focus leadership time on what matters most.</i>
                            <p></p>
                    </div>
                    <div class="col-lg-2 text-light">
                        <p><b>Quick Links</b></p>
                        <p><a class="py-3 text-light" href="/">Home</a></p>
                        <p><a class="py-3 text-light" href="/case-studies">Case Studies</a></p>
                        <p><a class="py-3 text-light" href="/insights/insights.php">Insights</a></p>
                        <p><a class="py-3 text-light" href="/insights/magazine.php">Magazine</a></p>
                        <p><a class="py-3 text-light" href="/careers">Careers</a></p>
                        <p><a class="py-3 text-light" href="/contact-us">Contact Us</a></p>
                        <p><a class="py-3 text-light" href="/about-us">About Us</a></p>
                        <p><a class="py-3 text-light" href="https://www.valuexpa.com/terms">Terms</a></p>
                        <p><a class="py-3 text-light" href="https://www.valuexpa.com/FAQs/">FAQs</a></p>

                        <p><a class="py-3 text-light" href="https://www.valuexpa.com/privacy">Privacy Policy</a></p>
                    </div>
                    <div class="col-lg-3 text-light">
                        <p><b>What we Do</b></p>
                        <p><a class="py-3 text-light" href="/Planing-and-Analysis-Made-Minimal">Extended Planning and
                            Analysis</a></p>
                        <p><a class="py-3 text-light" href="/Analytical-Process-Automation-and-Business-Intelligence">Advanced Analytics & Business Intelligence</a></p>
                        <p><a class="py-3 text-light" href="/Finance-Processes-Managed-Services">Finance Processes Managed Services</a></p>
                         <!-- <p><a class="py-3 text-light" href="https://www.valuexpa.com/energy/">Energy and Renewables Focus</a></p> -->
                          <!-- <p><a class="py-3 text-light" href="https://www.valuexpa.com/generative-ai-for-finance/">Generative AI For Finance</a></p> -->
                    </div>
                    <div class="col-lg-2 text-center">
                        <a href="https://www.linkedin.com/company/finpreneurs/?viewAsMember=true" target="_blank"
                           class="mx-3 text-light"><h2><i class="bi bi-linkedin"></i></h2></a>
                    </div>
                </div>

            </div>

            <div class="text-center text-light py-3">&copy; 2025 FinnAcer Technologies LLP.</div>
        </div>

    </div>




</template>

<script>
import ContactFooter from "./ContactFooter.vue"

export default {
    components: {
        ContactFooter
    }
}


</script>
<style lang="">

</style>




<script>

</script>
