<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td height="75">&nbsp;</td>
    </tr>
    <tr>
        <td>
            <table border="0" cellpadding="0" cellspacing="0" width="600" style="margin: auto; background:#f9f9f9;">
                <tbody>
                <tr>
                    <td colspan="3" height="20">&nbsp;</td>
                </tr>
                <tr>
                    <td width="20">&nbsp;</td>
                    <td>
                        <table border="0" cellpadding="0" cellspacing="0" >
                            <tbody>
                            <tr>
                                <td>
                                    <p style="text-align: center;">
                                        <img alt="" src="https://www.valuexpa.com/img/logo-mail.png" width="156.64" height="52">
                                    </p>

                                    <p>&nbsp;</p>
                                    <p style="font-size: 1.3em"><b>Hello, {{$name}}</b>.</p>
                                    <p>&nbsp;</p>

                                    <p>Thanks for visiting <a href="http://www.valuexpa.com/">www.valuexpa.com</a>. We appreciate your time to read through insights.</p>

                                    <p>Click <a href="https://www.valuexpa.com/{{ $pdf }}">here</a> to download a copy of our recently published Insight Report.</p>

                                    <p>Get to know how your organization can benefit from transforming your finance function and realize higher ROI!</p>

                                    <p>Connect with us today!</p>

                                    <p style="color: #1264a3;"><b>Team ValueXPA</b></p>

                                    <p>&nbsp;</p>
                                    <p style="color: #1264a3;"><b>XP&amp;A | Advanced Analytics &amp; Business Intelligence | Finance Processes Managed Services</b></p>
                                    <p><a href="http://www.valuexpa.com/">www.valuexpa.com</a></p>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td width="20">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" height="20">&nbsp;</td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr>
        <td height="75">&nbsp;</td>
    </tr>
</table>
