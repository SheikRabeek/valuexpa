<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td height="75">&nbsp;</td>
    </tr>
    <tr>
        <td>
            <table border="0" cellpadding="0" cellspacing="0" width="600" style="margin: auto; background:#f9f9f9;">
                <tbody>
                <tr>
                    <td colspan="3" height="20">&nbsp;</td>
                </tr>
                <tr>
                    <td width="20">&nbsp;</td>
                    <td>
                        <table border="0" cellpadding="0" cellspacing="0" >
                            <tbody>
                            <tr>
                                <td>
                                    <p style="text-align: center;">
                                        <img alt="" src="https://www.valuexpa.com/img/logo-mail.png" width="156.64" height="52">
                                    </p>

                                    <p>&nbsp;</p>
                                    <p style="font-size: 1em"><b>A User Request a Price: </b></p>

                                    <p><b>First Name:</b> {{$data['first_name']}}</p>
                                    <p><b>Last Name:</b> {{ $data['last_name'] }}</p>
                                    <p><b>Company Name:</b> {{ $data['company_name'] }}</p>
                                    <p><b>Phone Number:</b> {{ $data['phone'] }}</p>
                                    <p><b>Email Address:</b> {{ $data['email'] }}</p>
                                    <p><b>Industry:</b> {{ $data['industry'] }}</p>
                                    <p><b>Employees:</b> {{ $data['employees'] }}</p>
                                    <p><b>Revenue:</b> {{ $data['revenue'] }}</p>

                                    <p>&nbsp;</p>
                                    <p ><b>help transform business as trusted Finance Partner</b></p>
                                    <p style="color: #1264a3; text-align: center"><a style="color: #1264a3; text-align: center" href="http://www.valuexpa.com/">www.valuexpa.com</a></p>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td width="20">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" height="20">&nbsp;</td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr>
        <td height="75">&nbsp;</td>
    </tr>
</table>
