<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Download Your Publication</title>
</head>
<body>
    <h2>Thank you for your interest!</h2>
    
    <p>Dear <?php echo e($name); ?>,</p>
    
    <p>Thank you for downloading our publication: <strong><?php echo e($publicationTitle); ?></strong></p>
    
    <?php if($pdfUrl): ?>
    <p>You can download the publication using the link below:</p>
    <p>
        <a href="<?php echo e($pdfUrl); ?>" style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            Download Publication
        </a>
    </p>
    <?php else: ?>
    <p>We will send you the download link shortly once it's available.</p>
    <?php endif; ?>
    
    <p>Best regards,<br>ValueXPA Team</p>
</body>
</html><?php /**PATH D:\valuexpafinalcorrection\resources\views\mail\publication_download.blade.php ENDPATH**/ ?>