<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>New Publication Download</title>
</head>
<body>
    <h2>New Publication Download</h2>
    
    <p><strong>Publication:</strong> <?php echo e($publicationTitle); ?></p>
    <p><strong>User:</strong> <?php echo e($name); ?></p>
    <p><strong>Email:</strong> <?php echo e($email); ?></p>
    <p><strong>Date:</strong> <?php echo e(now()->format('Y-m-d H:i:s')); ?></p>
</body>
</html><?php /**PATH D:\valuexpafinalcorrection\resources\views\mail\publication_notification.blade.php ENDPATH**/ ?>